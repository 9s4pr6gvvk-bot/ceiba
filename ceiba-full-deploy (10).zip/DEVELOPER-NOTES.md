# CEIBA CMS — Developer Notes (Frankie)

Same stack as Well Connections, stripped to what CEIBA needs. No therapist/team
model — just **Blog (Journal)**, **Testimonials**, **enquiries**, and **live chat**, on
Cloudflare Pages + Functions + D1. No build step, no npm dependencies at runtime.

## Stack

- **Static pages**: `index.html`, `about.html`, `individuals.html`,
  `organisations.html`, `groups.html` — the originals, patched with a Journal nav
  link, the chat widget, and (on index) a testimonials slider + a "latest 2 posts"
  Journal strip.
- **Pages Functions** (`/functions`): the API + server-rendered Journal.
- **D1** (SQLite): tables in `schema.sql`.
- **Admin**: `/admin` single-page app (`admin/index.html`).
- **Chat widget**: `assets/chat.js`, included on every public page.

## Folder map

```
index.html, about.html, ...      public pages (patched)
admin/index.html                 the CMS (login + Journal/Testimonials/Messages)
assets/chat.js                   visitor chat widget (self-injecting)
functions/
  _shared.js                     auth (HMAC cookie), markdown, slug, escaping, Resend notify
  _layout.js                     server-render shell for Journal pages (matches design tokens)
  blog.js                        GET /blog        (listing)
  blog/[slug].js                 GET /blog/<slug> (single post, JSON-LD)
  sitemap.xml.js                 GET /sitemap.xml
  api/
    login.js  logout.js  me.js   session auth
    posts.js   posts/[id].js      blog CRUD (public GET published; admin all)
    testimonials.js  testimonials/[id].js
    submissions.js   submissions/[id].js   (discovery-call enquiries: public POST, admin list/read/delete)
    chat/
      thread.js send.js poll.js  visitor endpoints
      threads.js messages.js     admin endpoints (list / history+reply)
schema.sql  wrangler.toml  _headers  .dev.vars.example
```

## Routing model

The discovery-call form POSTs to `/api/submissions` (public): it validates, stores the enquiry in D1, and fires a Resend email to the owner with `reply_to` set to the enquirer, so she can reply straight from her inbox. The admin Enquiries tab lists them with an unread badge, mark-read, and delete.

Public `GET`s are open (published rows only). Everything that writes, plus the
admin chat endpoints and `?all=1` on posts, requires `requireAuth`, which now
verifies the `CF_Authorization` JWT cookie set by Cloudflare Access (see
"Admin authentication" below) — there's no app-level password anymore.

Markdown is rendered server-side in `_shared.js` (`markdown()`), and mirrored
client-side in the admin for live preview. **Input is HTML-escaped before any
markdown rules run**, so stored post bodies can't inject raw HTML/scripts.

## First-time setup

1. **Create the D1 database**
   ```
   npx wrangler d1 create ceiba-cms
   ```
   Copy the printed `database_id` into `wrangler.toml` (replace
   `PASTE_YOUR_DATABASE_ID_HERE`).

2. **Create the tables**
   ```
   npx wrangler d1 execute ceiba-cms --file=schema.sql --remote
   ```

3. **Create the Pages project & deploy** (from this folder)
   ```
   npx wrangler pages deploy
   ```
   (First run will offer to create the project — name it `ceiba-cms`.)

4. **Admin access is via Cloudflare Access, not a secret**
   `/admin*` is gated by a Cloudflare Access application (Access controls →
   Applications → destination `ceibamethod.co.uk/admin*`), and the `/api/*`
   endpoints verify the resulting `CF_Authorization` JWT server-side — see
   "Admin authentication" below. No `ADMIN_PASSWORD` / `SESSION_SECRET` to
   set here anymore.

That's it. `/admin` is live, public pages read from D1.

## Admin authentication

`/admin*` sits behind a Cloudflare Access application (Access controls →
Applications → "ceibamethod.co.uk", destination `ceibamethod.co.uk/admin*`).
Access only gates that page path though — it doesn't touch `/api/*` — so
`requireAuth()` in `_shared.js` independently verifies the `CF_Authorization`
cookie's JWT on every admin API call: signature (against Access's own JWKS
at `/cdn-cgi/access/certs`), audience (the app's AUD tag, hardcoded in
`_shared.js`), issuer, and expiry.

To change who can log in: edit the "CEIBA Admin Access" policy under Access
controls → Policies — add/remove allowed emails there, not in this codebase.

If the Access application is ever deleted and recreated, its AUD tag changes
and `ACCESS_AUD` in `_shared.js` needs updating to match, or every admin API
call will start failing with 401 even for legitimately logged-in users.

"Sign out" in the admin panel navigates to `/cdn-cgi/access/logout`, which is
a Cloudflare-managed endpoint (not one of our Pages Functions) that clears
the Access session cookie for this domain.

## Everyday deploy

```
npx wrangler pages deploy
```
Schema only needs re-running if `schema.sql` changes (`CREATE TABLE IF NOT EXISTS`
is safe to re-run).

## Local dev

```
npx wrangler d1 execute ceiba-cms --local --file=schema.sql
npx wrangler pages dev .
```
Note: local dev won't have a real Cloudflare Access session, so `/admin`
API calls will 401 locally unless you stub `requireAuth` or test against
the deployed environment instead.
(Offline, Miniflare warns it can't fetch the `Request.cf` object — harmless.)

## Phone notifications for chat (the client's requirement)

The chat already stores the visitor's email, so follow-up is never lost. For a
genuine push to her phone when a message lands, wire up **Resend** (free tier):

1. Create a Resend account, verify a sending domain (or use their test sender),
   grab an API key.
2. Add three variables to the Pages project:
   - `RESEND_API_KEY`
   - `NOTIFY_EMAIL` — her address (arrives as a phone push/notification email).
   - `NOTIFY_FROM` — e.g. `CEIBA <chat@ceibamethod.com>` once the domain's verified.
3. Done — the same three vars power BOTH notifications: `notifyChat()` fires on
   each new live-chat message, and `notifySubmission()` fires on each discovery-
   call enquiry (with `reply_to` = the enquirer). Both fail silently if the vars
   are absent, so nothing breaks without them.

For SMS specifically, swap the Resend call for a Twilio call in `notifyChat()` —
same shape, ~10 lines.

## Design decisions / notes

- Public nav label is **Journal** (reads better than "Blog" on a coaching brand);
  URLs stay `/blog` and `/blog/<slug>`. One-word change in `_layout.js` and the
  page nav if she prefers "Blog".
- Journal pages use a compact solid nav (no hero image behind them) rather than
  the home page's tall shrinking nav — deliberate, and correct for reading pages.
- The home page testimonial band falls back to the founder quote when there are
  no published testimonials.
- The discovery-call form no longer uses Formspree — it posts to `/api/submissions`
  and is captured in the CMS + emailed via Resend.
- Public write endpoints (`/api/submissions`, `/api/bookings`, `/api/chat/send`,
  and the "start conversation" step of `/api/chat/thread`) are rate limited
  per IP via a small D1-backed counter in `_shared.js` (`rateLimited()`). It's
  a fixed-window count in a `rate_limits` table the code creates itself on
  first use — no dashboard config, no extra bindings. Current limits: 5
  enquiries / 10 min, 5 bookings / 10 min, 20 chat messages / 5 min, 10 new
  chat conversations / 10 min. Bump the numbers in each endpoint if they turn
  out too tight; it fails open (never blocks) if the check itself errors.
- SEO is handled: per-post `<title>`, meta description, canonical, Open Graph,
  Article JSON-LD, and `/sitemap.xml`. `/admin` and `/api` are `noindex` via
  `_headers`.

## TODO before/after go-live

- [ ] Put the site on the real domain (`ceibamethod.com`) via Cloudflare, and
      update the hard-coded `ORIGIN`/canonical base in `_layout.js`,
      `blog/[slug].js`, `blog.js`, and `sitemap.xml.js` if the domain differs.
- [ ] Point Google Search Console at `/sitemap.xml`.
- [ ] Block the `*.pages.dev` preview from indexing (or just rely on canonical).
- [ ] Wire Resend (above) so she actually gets notified.
- [ ] Optional: R2 image uploads (needs a card on the Cloudflare account) to
      replace the paste-a-URL cover flow.
