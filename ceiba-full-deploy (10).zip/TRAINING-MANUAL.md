# CEIBA: Your Content Studio

A short guide to running your own website content. No code, no developer needed for day-to-day changes.

Everything happens in one place: **your website address followed by `/admin`** (for example `https://ceibamethod.co.uk/admin`). Bookmark it on your phone and your computer.

---

## Signing in

1. Go to `/admin`.
2. Sign in with your Google account (`gerry@ceibamethod.co.uk`) and follow the prompts.
3. You'll stay signed in for about a month on that device, then you'll be asked again.

If sign-in isn't working, ask Frankie. Access is controlled centrally, not something you can reset from here.

---

## The tabs

Along the top:

- **Journal**: your blog posts.
- **Testimonials**: the quotes that rotate on your home page.
- **Enquiries**: discovery call requests from the booking form.
- **Bookings**: consultation slot requests, plus your availability settings.
- **Pricing**: the figures shown on your site's pricing sections.
- **Messages**: the live chat inbox from your website visitors.
- **Settings**: the wording used in your automated booking emails.

**If you ever feel lost:** every page has a small round **?** button next to its title. Tap it for a short, plain explanation of what that page does and what to do. Nothing on any screen can damage your website, so it is always safe to look around.

---

## Journal (blog posts)

**To write a new post:**

1. Tap **Journal → + New post**.
2. Fill in:
   - **Title**: the headline.
   - **URL slug**: fills itself in from the title (e.g. `growing-from-change`). You can leave it alone.
   - **Cover image**: optional. Tap **Upload** to choose a photo from your device (see "Images" below), or paste a link if you already have one.
   - **Body**: your writing.
3. Tick **Published** when it's ready. Leave it unticked to save a **Draft** only you can see.
4. Tap **Save post**.

The short summary that appears on the Journal list, in Google, and when a post is shared on social media is created for you automatically from the opening of your post. There's nothing to fill in.

**Formatting your writing:** the Body box works like a normal document. Type straight into it and what you see is what visitors see. To format, select some text and use the buttons along the top:

- **Text style** dropdown: turn a line into a **Heading**, a **Small heading**, or a **Quote**, or back to **Normal text**.
- **B** for bold and *i* for italic.
- **• List** for bullets, **1. List** for a numbered list.
- **Link**: select the words you want to link, tap **Link**, and paste the web address.
- **+ Insert image**: see "Images" below.

There's no separate preview to check any more, because the writing box already shows the finished look. Just write.

**To edit or delete a post:** open **Journal**, tap **Edit** on the post, make your changes and **Save**. Or scroll down and tap **Delete**.

---

## Testimonials

These rotate automatically in the quote band on your home page.

1. Tap **Testimonials → + New testimonial**.
2. Enter the **Quote**, and optionally an **Attribution** (a first name or "Client") and a **Context** ("Individual client", "Team leader", etc.).
3. **Order** controls which shows first. Lower numbers come first. Leave at 0 if it doesn't matter.
4. Tick **Published** and **Save**.

With several testimonials, the home page shows arrows and dots so visitors can move between them. With none, it shows your founder quote instead.

---

## Enquiries (discovery call requests)

When someone fills in the **Book a discovery call** form, it lands here, and you also get an email straight away.

- A **red number** on the Enquiries tab shows how many you haven't looked at yet.
- Each request shows their **name, email, phone** (if given), **their message**, and when it came in. New ones are outlined and marked **New**.
- **Reply by email** opens your email app with their address filled in. You can also just reply to the notification email; it's set up so your reply goes straight to them.
- **Quick reply buttons** sit next to it, one for each saved reply you've set up. Tapping one opens your email with the whole reply already written (and their first name filled in), so you only need to read it over and send. You manage these under Messages → Chat widget settings → Quick replies.
- **Mark read** clears the "New" flag. **Delete** removes it once you're done.

**The email notification:** every request is emailed to you the moment it's sent, so you don't have to keep checking the dashboard. Replying to that email reaches the person directly. (This uses Resend. Frankie sets it up once; see the developer notes.)

---

## Bookings (consultation slots)

When someone picks a specific time slot on your website, rather than just leaving a message, it lands here as a request you accept or decline.

**Setting your availability:** tap **Availability settings** to expand it.

- **Days open**: tick which days of the week you take calls.
- **First slot / Last slot ends by**: your working hours for bookings.
- **Slot length**: how long each consultation is.
- **Gap between slots**: a buffer between back-to-back bookings, if you want one.
- **Min notice**: how much advance warning you need (24 hours means no one can book for later today).
- **Days ahead to open**: how far into the future people can see and book.
- **Timezone**: should already be correct. Only change it if you move.

Save after any change. It takes effect immediately on the site's booking calendar.

**Handling a request:**

- Tap **Accept** or **Decline**. A card opens showing the exact email that will go to the client, with their name and the date and time already filled in.
- Read it over and change anything you like, the subject or the message, right there in the card. Add a personal line, take one out, whatever suits.
- When you're happy, tap **Send**. That is the moment the email goes and the booking is confirmed or declined. Nothing is sent until you tap Send, so tapping Accept or Decline by mistake is easy to undo: just tap **Cancel**.
- The **Settings** tab sets the starting wording for these emails, so if you find yourself making the same change every time, update it there once and the card will start from your new version.

**If two bookings clash:** when two requests are for overlapping times, a note at the top of the Bookings tab warns you, and each clashing request is outlined and marked with the name it overlaps. If you try to accept a time that overlaps one you've already accepted, you'll get a warning first so you don't double-book yourself. Nothing stops you accepting both on purpose (for a joint session, say), it just makes sure it's a choice, not an accident.

---

## Pricing

The **Pricing** tab controls the figures shown on your homepage, Individuals page, and Groups page:

- **Individual session** and **Full programme**: shown on the homepage and Individuals page.
- **Group programme**, and its **was price** (for showing a discount): shown on the Groups page.

Change a number and tap **Save prices**. It updates on the live site immediately, no code involved.

---

## Messages (live chat)

A **Chat with us** button sits in the bottom corner of every page. When someone messages you, it lands here.

- A **red number** on the Messages tab shows how many conversations have something new.
- Tap a conversation to read it and reply. The visitor sees your reply appear live if they still have the chat open, and it's waiting for them if they come back later.
- If they left an **email**, you'll see it at the top of the conversation, so you can follow up even if they've closed the site.

**Answering from your phone:** open `/admin` on your phone and go to **Messages**. It's built to work on a small screen.

**Quick replies:** above the reply box you'll see small buttons for your saved replies. Tap one and it drops the full reply into the box, ready for you to tweak and send. The same buttons appear under each enquiry (they open your email with the reply already written). Wherever you've typed `{{name}}` in a saved reply, it's swapped for the person's first name automatically. You set these up in **Chat widget settings → Quick replies** (tap **+ Add quick reply**, give it a short button label and the wording, and **Save chat settings**). Good ones to start with: a warm "thanks, tell me more", and one that points people to booking a discovery call.

**A note on expectations:** the chat says "we usually reply within a few hours". You don't need to be glued to it. Reply when you can. Because you capture the visitor's email, no enquiry is lost.

---

## Settings (booking emails)

Three automated emails go out to clients around a booking, and the **Settings** tab is where you write what each one says:

- **Booking requested**: sent the instant someone submits a booking, before you've done anything.
- **Booking confirmed**: sent when you accept a request.
- **Booking declined**: sent when you decline one.

Type `{{name}}` and `{{when}}` anywhere in the message. They're swapped for the client's actual name and the actual date/time when the email goes out, so you only need to write the template once.

The whole email is here, including the sign-off at the bottom, so you can change that too if you'd like. This wording is the starting point. When you accept or decline a specific booking, a card lets you tweak it for that one client before it sends, without changing the template here.

---

## Images

**Cover image:** on the post editor, tap **Upload** next to the Cover image field, choose a photo from your device, and it fills the field in automatically once done. A small preview appears underneath.

**Images inside a post:** tap **+ Insert image** above the writing box, choose a photo, and it drops into your text at your cursor. Edit the bit in square brackets to add a caption if you want one (it's the alt text, e.g. change `![](...)` to `![A quiet morning by the water](...)`).

Accepted formats: JPG, PNG, WebP, GIF. Max size 8MB per image. If your phone's photo is bigger, most phones let you choose a smaller size when sharing or exporting it.

**A 500-photo limit:** your image library holds up to 500 uploads in total. If you're at the limit and try to upload another, you'll be asked whether to delete your oldest uploaded photo to make room. Say no and cancel if you're not sure. If that oldest photo is still the cover image or embedded in an older post, deleting it will leave a broken image there. In practice, 500 is a lot of photos for a blog, so this is unlikely to come up soon.

---

## Quick answers

- **My post isn't showing on the site.** Check the **Published** tick is on.
- **I made a typo in a live post.** Edit it and Save. Changes are instant.
- **Can I unpublish without deleting?** Yes. Untick **Published** and Save. It moves back to draft and disappears from the site, but you keep it.
- **Is `/admin` visible to the public?** No. It's hidden from Google and needs you to sign in with your Google account.
