/* CEIBA calendar booking widget.
   Self-contained: injects its own modal + styles, wired to any element with
   [data-open-modal] or [data-book]. Talks to /api/availability and /api/bookings.
   Styled to match the CEIBA palette (forest / gold / cream). */
(function () {
  'use strict';

  var CSS = ''
    + '#ceibaBook{position:fixed;inset:0;z-index:400;display:none;overflow-y:auto;padding:1rem;'
    + 'background:rgba(17,28,22,.62);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);}'
    + '#ceibaBook.open{display:block;}'
    + '#ceibaBook .cb-modal{max-width:480px;margin:4vh auto;background:var(--white,#FBF9F3);border-radius:8px;'
    + 'padding:30px 30px 34px;box-shadow:0 30px 80px -20px rgba(17,34,27,.5);position:relative;}'
    + '#ceibaBook .cb-head{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:.2rem;}'
    + '#ceibaBook .cb-head-l{display:flex;align-items:flex-start;gap:.7rem;}'
    + '#ceibaBook .cb-kicker{display:block;font-size:10px;letter-spacing:.22em;text-transform:uppercase;color:var(--gold-deep,#A6712B);margin-bottom:.3rem;font-weight:500;}'
    + '#ceibaBook h3{font-family:"Cormorant Garamond",serif;font-size:1.7rem;font-weight:500;color:var(--forest,#1F4434);line-height:1.15;margin:0;}'
    + '#ceibaBook .cb-back,#ceibaBook .cb-close{background:none;border:none;cursor:pointer;color:var(--muted,#5E665C);line-height:1;padding:.1rem;}'
    + '#ceibaBook .cb-back{font-size:1.2rem;display:none;margin-top:.15rem;}'
    + '#ceibaBook .cb-close{font-size:1.5rem;}'
    + '#ceibaBook .cb-lead{font-size:13.5px;color:var(--muted,#5E665C);line-height:1.6;margin:.5rem 0 1.2rem;}'
    + '#ceibaBook .cb-choice{display:flex;flex-direction:column;gap:.7rem;}'
    + '#ceibaBook .cb-choice-btn{display:grid;grid-template-columns:auto 1fr;grid-template-rows:auto auto;column-gap:.9rem;align-items:center;text-align:left;'
    + 'background:var(--white,#fff);border:1px solid var(--border,#D8CDB4);border-radius:6px;padding:1rem 1.1rem;cursor:pointer;transition:border-color .18s,background .18s;}'
    + '#ceibaBook .cb-choice-btn:hover{border-color:var(--forest,#1F4434);background:var(--bg,#F4EFE3);}'
    + '#ceibaBook .cb-choice-ic{grid-row:1/3;width:44px;height:44px;border-radius:50%;background:var(--bg,#F4EFE3);display:flex;align-items:center;justify-content:center;color:var(--forest,#1F4434);}'
    + '#ceibaBook .cb-choice-t{font-family:"Cormorant Garamond",serif;font-size:1.2rem;color:var(--forest,#1F4434);font-weight:500;}'
    + '#ceibaBook .cb-choice-s{font-size:12.5px;color:var(--muted,#5E665C);}'
    + '#ceibaBook .cb-loading,#ceibaBook .cb-empty{text-align:center;padding:1.6rem 0;color:var(--muted,#5E665C);font-size:14px;}'
    + '#ceibaBook .cb-monthbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:.7rem;}'
    + '#ceibaBook .cb-monthbar button{background:none;border:1px solid var(--border,#D8CDB4);border-radius:6px;padding:.25rem .65rem;cursor:pointer;font-size:1rem;color:var(--muted,#5E665C);}'
    + '#ceibaBook .cb-monthbar span{font-family:"Cormorant Garamond",serif;font-size:1.15rem;font-weight:600;color:var(--forest,#1F4434);}'
    + '#ceibaBook .cb-dow{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;margin-bottom:4px;text-align:center;}'
    + '#ceibaBook .cb-dow span{font-size:10px;letter-spacing:.1em;color:var(--subtle,#8E948A);padding:.2rem 0;}'
    + '#ceibaBook .cb-days{display:grid;grid-template-columns:repeat(7,1fr);gap:3px;}'
    + '#ceibaBook .cb-days button{aspect-ratio:1;display:flex;align-items:center;justify-content:center;border-radius:8px;'
    + 'border:1px solid transparent;background:var(--bg,#F4EFE3);color:var(--forest,#1F4434);cursor:pointer;'
    + 'font-family:inherit;font-size:.9rem;font-weight:500;transition:all .15s;}'
    + '#ceibaBook .cb-days button:hover{background:var(--sage-soft,#C3D4C4);}'
    + '#ceibaBook .cb-days button.on{background:var(--forest,#1F4434);color:#fff;border-color:var(--forest,#1F4434);}'
    + '#ceibaBook .cb-days .cb-empty-cell{aspect-ratio:1;display:flex;align-items:center;justify-content:center;font-size:.9rem;color:rgba(94,102,92,.3);}'
    + '#ceibaBook .cb-slots-label{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--gold-deep,#A6712B);margin-bottom:.7rem;}'
    + '#ceibaBook .cb-slots{display:flex;flex-wrap:wrap;gap:.45rem;}'
    + '#ceibaBook .cb-slots button{padding:.55rem 1.1rem;border:1px solid var(--border,#D8CDB4);border-radius:22px;background:var(--white,#fff);'
    + 'color:var(--forest,#1F4434);cursor:pointer;font-family:inherit;font-size:.88rem;transition:all .15s;}'
    + '#ceibaBook .cb-slots button:hover{border-color:var(--forest,#1F4434);background:var(--bg,#F4EFE3);}'
    + '#ceibaBook .cb-chosen{background:var(--bg,#F4EFE3);border-radius:6px;padding:.65rem .85rem;margin-bottom:1rem;'
    + 'display:flex;align-items:center;justify-content:space-between;gap:.75rem;}'
    + '#ceibaBook .cb-chosen strong{font-size:14px;color:var(--forest,#1F4434);font-weight:500;}'
    + '#ceibaBook .cb-change{background:none;border:none;color:var(--gold-deep,#A6712B);font-size:12px;cursor:pointer;text-decoration:underline;white-space:nowrap;}'
    + '#ceibaBook .cb-field{margin-bottom:.85rem;}'
    + '#ceibaBook .cb-row{display:flex;gap:.6rem;flex-wrap:wrap;}'
    + '#ceibaBook .cb-row .cb-field{flex:1;min-width:150px;}'
    + '#ceibaBook label{display:block;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted,#5E665C);margin-bottom:.3rem;}'
    + '#ceibaBook input,#ceibaBook select,#ceibaBook textarea{width:100%;padding:.65rem .8rem;border:1px solid var(--border,#D8CDB4);'
    + 'border-radius:4px;font-family:inherit;font-size:16px;background:#fff;color:var(--text,#232A24);}'
    + '#ceibaBook input:focus,#ceibaBook select:focus,#ceibaBook textarea:focus{outline:none;border-color:var(--forest-mid,#3A6B52);}'
    + '#ceibaBook textarea{resize:vertical;}'
    + '#ceibaBook .cb-err{color:#b3402f;font-size:13px;min-height:1rem;margin-bottom:.4rem;}'
    + '#ceibaBook .cb-submit{width:100%;background:var(--gold,#C08A3E);color:#fff;border:none;cursor:pointer;padding:.85rem;'
    + 'font-size:11px;letter-spacing:.14em;text-transform:uppercase;font-weight:500;border-radius:2px;transition:background .25s;}'
    + '#ceibaBook .cb-submit:hover{background:var(--gold-deep,#A6712B);}'
    + '#ceibaBook .cb-submit:disabled{opacity:.6;cursor:default;}'
    + '#ceibaBook .cb-fineprint{font-size:11px;color:var(--subtle,#8E948A);text-align:center;margin-top:.7rem;}'
    + '#ceibaBook .cb-success{text-align:center;padding:.75rem 0 .25rem;}'
    + '#ceibaBook .cb-success .cb-tick{width:52px;height:52px;border-radius:50%;background:var(--sage-soft,#C3D4C4);'
    + 'display:flex;align-items:center;justify-content:center;margin:0 auto .9rem;}'
    + '#ceibaBook .cb-success h3{margin-bottom:.5rem;}'
    + '#ceibaBook .cb-success p{font-size:14px;color:var(--muted,#5E665C);line-height:1.6;max-width:340px;margin:0 auto 1.25rem;}'
    + '#ceibaBook .cb-dismiss{border:1px solid var(--border,#D8CDB4);background:none;color:var(--forest,#1F4434);cursor:pointer;'
    + 'padding:.6rem 1.4rem;border-radius:2px;font-size:11px;letter-spacing:.14em;text-transform:uppercase;}'
    + '#cbmTurnstile,#cbTurnstile{max-width:100%;overflow:hidden;margin-bottom:.4rem;}';

  var HTML = ''
    + '<div class="cb-modal" role="dialog" aria-modal="true" aria-labelledby="cbTitle">'
    + '  <div class="cb-head"><div class="cb-head-l">'
    + '    <button type="button" class="cb-back" id="cbBack" aria-label="Back">&#8592;</button>'
    + '    <div><span class="cb-kicker">Free Discovery Call</span>'
    + '    <h3 id="cbTitle">Choose a date</h3></div>'
    + '  </div><button type="button" class="cb-close" id="cbClose" aria-label="Close">&times;</button></div>'
    + '  <p class="cb-lead" id="cbLead">How would you like to get in touch?</p>'
    + '  <div id="cbStep0">'
    + '    <div class="cb-choice">'
    + '      <button type="button" class="cb-choice-btn" id="cbChooseCal">'
    + '        <span class="cb-choice-ic"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24"><rect x="3" y="4.5" width="18" height="16" rx="2"/><path stroke-linecap="round" d="M3 9h18M8 2.5v4M16 2.5v4"/></svg></span>'
    + '        <span class="cb-choice-t">Book a time</span>'
    + '        <span class="cb-choice-s">Pick a slot for a free discovery call</span>'
    + '      </button>'
    + '      <button type="button" class="cb-choice-btn" id="cbChooseMsg">'
    + '        <span class="cb-choice-ic"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M4 5h16v12H7l-3 3V5z"/></svg></span>'
    + '        <span class="cb-choice-t">Send a message</span>'
    + '        <span class="cb-choice-s">Prefer to write? I’ll reply by email</span>'
    + '      </button>'
    + '    </div>'
    + '  </div>'
    + '  <div id="cbStepMsg" style="display:none;">'
    + '    <div class="cb-field"><label for="cbmName">Your name *</label><input id="cbmName" type="text" autocomplete="name" /></div>'
    + '    <div class="cb-row">'
    + '      <div class="cb-field"><label for="cbmEmail">Email *</label><input id="cbmEmail" type="email" autocomplete="email" /></div>'
    + '      <div class="cb-field"><label for="cbmPhone">Phone</label><input id="cbmPhone" type="tel" autocomplete="tel" /></div>'
    + '    </div>'
    + '    <div class="cb-field"><label for="cbmMsg">What’s bringing you here?</label><textarea id="cbmMsg" rows="3" placeholder="A few words about what you’re navigating right now…"></textarea></div>'
    + '    <div id="cbmTurnstile"></div>'
    + '    <div class="cb-err" id="cbmErr"></div>'
    + '    <button type="button" class="cb-submit" id="cbmSubmit">Send Message</button>'
    + '    <p class="cb-fineprint">Your details are kept private and used only to arrange your call.</p>'
    + '  </div>'
    + '  <div id="cbStep1a" style="display:none;">'
    + '    <div class="cb-loading" id="cbLoading">Loading available times\u2026</div>'
    + '    <div id="cbCal" style="display:none;">'
    + '      <div class="cb-monthbar"><button type="button" id="cbPrev">&#8249;</button>'
    + '      <span id="cbMonth"></span><button type="button" id="cbNext">&#8250;</button></div>'
    + '      <div class="cb-dow"><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span><span>S</span></div>'
    + '      <div class="cb-days" id="cbDays"></div>'
    + '    </div>'
    + '    <div class="cb-empty" id="cbEmpty" style="display:none;">No times available right now. '
    + '      <a href="#" id="cbEmptyContact" style="color:var(--gold-deep,#A6712B);">Send an enquiry</a> instead and I\u2019ll be in touch.</div>'
    + '  </div>'
    + '  <div id="cbStep1b" style="display:none;">'
    + '    <p class="cb-slots-label" id="cbSlotsLabel"></p><div class="cb-slots" id="cbSlots"></div>'
    + '  </div>'
    + '  <div id="cbStep2" style="display:none;">'
    + '    <div class="cb-chosen"><strong id="cbChosen"></strong><button type="button" class="cb-change" id="cbChange">Change</button></div>'
    + '    <div class="cb-field"><label for="cbName">Your name *</label><input id="cbName" type="text" autocomplete="name" /></div>'
    + '    <div class="cb-row">'
    + '      <div class="cb-field"><label for="cbEmail">Email *</label><input id="cbEmail" type="email" autocomplete="email" /></div>'
    + '      <div class="cb-field"><label for="cbPhone">Phone</label><input id="cbPhone" type="tel" autocomplete="tel" /></div>'
    + '    </div>'
    + '    <div class="cb-field"><label for="cbService">What\u2019s it about?</label><select id="cbService">'
    + '      <option value="" selected>Select\u2026</option>'
    + '      <option>Individual coaching</option>'
    + '      <option>Leadership &amp; people development</option>'
    + '      <option>Organisation / team programme</option>'
    + '      <option>Group programme</option>'
    + '      <option>Not sure yet</option>'
    + '    </select></div>'
    + '    <div class="cb-field"><label for="cbNote">Anything else? (optional)</label><textarea id="cbNote" rows="2"></textarea></div>'
    + '    <div id="cbTurnstile"></div>'
    + '    <div class="cb-err" id="cbErr"></div>'
    + '    <button type="button" class="cb-submit" id="cbSubmit">Request This Time</button>'
    + '    <p class="cb-fineprint">Your details are kept private and used only to arrange your call.</p>'
    + '  </div>'
    + '  <div class="cb-success" id="cbSuccess" style="display:none;">'
    + '    <div class="cb-tick"><svg width="24" height="24" fill="none" stroke="var(--forest,#1F4434)" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5"/></svg></div>'
    + '    <h3>Request sent</h3><p id="cbSuccessMsg">Thank you. I\u2019ll confirm your call by email shortly.</p>'
    + '    <button type="button" class="cb-dismiss" id="cbDismiss">Close</button>'
    + '  </div>'
    + '</div>';

  var TURNSTILE_SITEKEY = '0x4AAAAAAEyygIGS92a2qFLq';

  function init() {
    var style = document.createElement('style');
    style.textContent = CSS;
    document.head.appendChild(style);
    var root = document.createElement('div');
    root.id = 'ceibaBook';
    root.innerHTML = HTML;
    document.body.appendChild(root);

    var cbmTurnstileId = null, cbTurnstileId = null;
    (function renderBookingTurnstile(){
      function doRender(){
        var mEl = document.getElementById('cbmTurnstile');
        var bEl = document.getElementById('cbTurnstile');
        if (mEl && window.turnstile) cbmTurnstileId = turnstile.render(mEl, { sitekey: TURNSTILE_SITEKEY });
        if (bEl && window.turnstile) cbTurnstileId = turnstile.render(bEl, { sitekey: TURNSTILE_SITEKEY });
      }
      if (window.turnstile) doRender();
      else {
        var iv = setInterval(function(){ if (window.turnstile){ clearInterval(iv); doRender(); } }, 150);
      }
    })();

    var $ = function (id) { return document.getElementById(id); };
    var step0 = $('cbStep0'), stepMsg = $('cbStepMsg');
    var step1a = $('cbStep1a'), step1b = $('cbStep1b'), step2 = $('cbStep2'), success = $('cbSuccess');
    var lead = $('cbLead');
    var err = $('cbErr'), cal = $('cbCal'), loading = $('cbLoading'), empty = $('cbEmpty');
    var daysEl = $('cbDays'), slotsEl = $('cbSlots'), slotsLabel = $('cbSlotsLabel'), monthLabel = $('cbMonth');
    var chosenEl = $('cbChosen'), titleEl = $('cbTitle'), backBtn = $('cbBack');
    var availability = null, activeDay = -1, chosenSlot = null, loaded = false, viewMonth = null, pendingPrefill = '';

    function todayStr() { var n = new Date(); return n.getFullYear() + '-' + ('0' + (n.getMonth() + 1)).slice(-2) + '-' + ('0' + n.getDate()).slice(-2); }
    function dayMap() { var m = {}; if (availability) availability.days.forEach(function (d, i) { m[d.date] = i; }); return m; }

    function showStep(w) {
      step0.style.display = w === '0' ? '' : 'none';
      stepMsg.style.display = w === 'msg' ? '' : 'none';
      step1a.style.display = w === '1a' ? '' : 'none';
      step1b.style.display = w === '1b' ? '' : 'none';
      step2.style.display = w === '2' ? '' : 'none';
      success.style.display = w === 'ok' ? '' : 'none';
      backBtn.style.display = (w === '1b' || w === '2' || w === 'msg' || w === '1a') ? '' : 'none';
      var titles = { '0': 'Get in touch', 'msg': 'Send a message', '1a': 'Choose a date', '1b': 'Choose a time', '2': 'Your details', 'ok': 'Sent' };
      titleEl.textContent = titles[w] || 'Get in touch';
      if (lead) lead.style.display = (w === '0') ? '' : 'none';
    }

    function renderCal() {
      if (!availability || !availability.days.length) return;
      var map = dayMap();
      if (!viewMonth) { var f = availability.days[0].date.split('-'); viewMonth = { y: +f[0], m: +f[1] }; }
      var y = viewMonth.y, mo = viewMonth.m;
      monthLabel.textContent = new Date(y, mo - 1, 1).toLocaleString('en-GB', { month: 'long', year: 'numeric' });
      var firstDow = (new Date(y, mo - 1, 1).getDay() + 6) % 7;
      var dim = new Date(y, mo, 0).getDate();
      var cells = '';
      for (var e = 0; e < firstDow; e++) cells += '<div class="cb-empty-cell"></div>';
      for (var d = 1; d <= dim; d++) {
        var ds = y + '-' + (mo < 10 ? '0' + mo : mo) + '-' + (d < 10 ? '0' + d : d);
        var idx = map.hasOwnProperty(ds) ? map[ds] : -1;
        if (idx >= 0) {
          cells += '<button type="button" data-dayidx="' + idx + '" class="' + (idx === activeDay ? 'on' : '') + '">' + d + '</button>';
        } else {
          cells += '<div class="cb-empty-cell"' + (ds === todayStr() ? ' style="color:var(--forest,#1F4434);font-weight:600;"' : '') + '>' + d + '</div>';
        }
      }
      daysEl.innerHTML = cells;
      Array.prototype.forEach.call(daysEl.querySelectorAll('button[data-dayidx]'), function (btn) {
        btn.onclick = function () { activeDay = +btn.getAttribute('data-dayidx'); renderCal(); showSlots(); };
      });
      $('cbPrev').onclick = function () { var p = new Date(y, mo - 2, 1); viewMonth = { y: p.getFullYear(), m: p.getMonth() + 1 }; renderCal(); };
      $('cbNext').onclick = function () { var n = new Date(y, mo, 1); viewMonth = { y: n.getFullYear(), m: n.getMonth() + 1 }; renderCal(); };
    }

    function showSlots() {
      if (activeDay < 0 || !availability) return;
      var day = availability.days[activeDay];
      slotsLabel.textContent = day.label;
      slotsEl.innerHTML = day.slots.map(function (s) {
        return '<button type="button" data-slot="' + s.start + '">' + s.label + '</button>';
      }).join('');
      Array.prototype.forEach.call(slotsEl.querySelectorAll('button'), function (btn) {
        btn.onclick = function () {
          chosenSlot = btn.getAttribute('data-slot');
          chosenEl.textContent = day.label + ', ' + btn.textContent;
          err.textContent = ''; showStep('2');
          setTimeout(function () { $('cbName').focus(); }, 50);
        };
      });
      showStep('1b');
    }

    function loadAvailability() {
      loading.style.display = ''; cal.style.display = 'none'; empty.style.display = 'none';
      fetch('/api/availability').then(function (r) { return r.json(); }).then(function (d) {
        loaded = true; availability = d; loading.style.display = 'none';
        if (!d.days || !d.days.length) { empty.style.display = ''; return; }
        cal.style.display = ''; renderCal();
      }).catch(function () { loading.style.display = 'none'; empty.style.display = ''; });
    }

    function open(prefill) {
      err.textContent = ''; chosenSlot = null; activeDay = -1; showStep('0');
      root.classList.add('open'); document.body.style.overflow = 'hidden';
      pendingPrefill = prefill || '';
    }
    function openCalendar() {
      showStep('1a');
      if (pendingPrefill) { var s = $('cbService'); for (var i = 0; i < s.options.length; i++) { if (s.options[i].value.toLowerCase().indexOf(pendingPrefill.toLowerCase()) > -1) { s.selectedIndex = i; break; } } }
      if (!loaded) loadAvailability();
    }
    function close() { root.classList.remove('open'); document.body.style.overflow = ''; }
    window.openBooking = open;

    $('cbChooseCal').onclick = function () { openCalendar(); };
    $('cbChooseMsg').onclick = function () { $('cbmErr').textContent = ''; showStep('msg'); setTimeout(function () { $('cbmName').focus(); }, 50); };

    backBtn.onclick = function () {
      if (step2.style.display === '') { err.textContent = ''; showStep('1b'); return; }
      if (step1b.style.display === '') { activeDay = -1; renderCal(); showStep('1a'); return; }
      // from calendar (1a) or message form -> back to chooser
      showStep('0');
    };
    $('cbClose').onclick = close;
    $('cbDismiss').onclick = close;
    $('cbChange').onclick = function () { err.textContent = ''; showStep('1b'); };
    $('cbEmptyContact').onclick = function (e) { e.preventDefault(); $('cbmErr').textContent = ''; showStep('msg'); setTimeout(function () { $('cbmName').focus(); }, 50); };
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && root.classList.contains('open')) close(); });
    root.addEventListener('click', function (e) { if (e.target === root) close(); });

    // Message form submit -> /api/submissions (existing enquiry pipeline).
    $('cbmSubmit').onclick = function () {
      var e2 = $('cbmErr'); e2.textContent = '';
      var payload = { name: $('cbmName').value.trim(), email: $('cbmEmail').value.trim(), phone: $('cbmPhone').value.trim(), message: $('cbmMsg').value.trim() };
      if (!payload.name) { e2.textContent = 'Please enter your name.'; return; }
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(payload.email)) { e2.textContent = 'Please enter a valid email address.'; return; }
      payload.turnstileToken = (window.turnstile && cbmTurnstileId != null) ? turnstile.getResponse(cbmTurnstileId) : '';
      var btn = $('cbmSubmit'); btn.disabled = true; btn.textContent = 'Sending\u2026';
      fetch('/api/submissions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
        .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
        .then(function (res) {
          btn.disabled = false; btn.textContent = 'Send Message';
          if (!res.ok) {
            e2.textContent = (res.d && res.d.error) || 'Something went wrong. Please try again.';
            if (window.turnstile && cbmTurnstileId != null) turnstile.reset(cbmTurnstileId);
            return;
          }
          $('cbSuccessMsg').textContent = 'Thank you. Your message has been sent and I\u2019ll be in touch within one working day.';
          showStep('ok');
        })
        .catch(function () {
          btn.disabled = false; btn.textContent = 'Send Message'; e2.textContent = 'Network error. Please try again.';
          if (window.turnstile && cbmTurnstileId != null) turnstile.reset(cbmTurnstileId);
        });
    };

    $('cbSubmit').onclick = function () {
      err.textContent = '';
      if (!chosenSlot) { err.textContent = 'Please choose a time first.'; showStep('1a'); return; }
      var payload = {
        name: $('cbName').value.trim(), email: $('cbEmail').value.trim(),
        phone: $('cbPhone').value.trim(), service: $('cbService').value,
        slot_start: chosenSlot, note: $('cbNote').value.trim(),
      };
      if (!payload.name) { err.textContent = 'Please enter your name.'; return; }
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(payload.email)) { err.textContent = 'Please enter a valid email address.'; return; }
      payload.turnstileToken = (window.turnstile && cbTurnstileId != null) ? turnstile.getResponse(cbTurnstileId) : '';
      var btn = $('cbSubmit'); btn.disabled = true; btn.textContent = 'Sending\u2026';
      fetch('/api/bookings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
        .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, status: r.status, d: d }; }); })
        .then(function (res) {
          btn.disabled = false; btn.textContent = 'Request This Time';
          if (res.status === 409) { err.textContent = (res.d && res.d.error) || 'That time was just taken. Please choose another.'; loaded = false; showStep('1a'); loadAvailability(); return; }
          if (!res.ok) {
            err.textContent = (res.d && res.d.error) || 'Something went wrong. Please try again.';
            if (window.turnstile && cbTurnstileId != null) turnstile.reset(cbTurnstileId);
            return;
          }
          if (res.d && res.d.when) $('cbSuccessMsg').textContent = 'Thank you. I\u2019ll confirm your call for ' + res.d.when + ' by email shortly.';
          showStep('ok');
        })
        .catch(function () {
          btn.disabled = false; btn.textContent = 'Request This Time'; err.textContent = 'Network error. Please try again.';
          if (window.turnstile && cbTurnstileId != null) turnstile.reset(cbTurnstileId);
        });
    };

    // Hook every existing booking trigger to the calendar instead of the old form.
    Array.prototype.forEach.call(document.querySelectorAll('[data-open-modal],[data-book]'), function (el) {
      el.addEventListener('click', function (e) { e.preventDefault(); e.stopImmediatePropagation(); open(el.getAttribute('data-book') || ''); }, true);
    });
    if (location.hash === '#book') open('');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
