/* CEIBA live chat widget — self-contained, no dependencies.
   Include on any page with: <script src="/assets/chat.js" defer></script> */
(function () {
  if (window.__ceibaChat) return; window.__ceibaChat = true;

  var LS_TOKEN = 'ceiba_chat_token';
  var LS_SEEN = 'ceiba_chat_seen';
  var token = localStorage.getItem(LS_TOKEN) || '';
  var lastId = parseInt(localStorage.getItem(LS_SEEN) || '0', 10) || 0;
  var seenIds = new Set();
  var open = false, pollTimer = null, started = false;
  var prechatName = '', prechatEmail = '';
  var TURNSTILE_SITEKEY = '0x4AAAAAAEyygIGS92a2qFLq';
  var cbcTurnstileId = null;

  // Editable copy — CMS values (fetched below) override these defaults once loaded.
  var cfg = {
    chat_launcher_text: 'Chat with us',
    chat_subtitle: 'We usually reply within a few hours',
    chat_intro: "Hello — thanks for stopping by. Leave a message and I'll get back to you personally. If it's outside working hours I'll reply as soon as I can.",
    chat_auto_cta: 'Send a message or book a call',
  };

  var css = `
  .cbc-launch{position:fixed;right:24px;bottom:24px;z-index:150;display:inline-flex;align-items:center;gap:10px;
    background:#1F4434;color:#FBF9F3;border:none;cursor:pointer;font-family:'Outfit',system-ui,sans-serif;
    font-size:13px;font-weight:500;letter-spacing:.02em;padding:13px 20px 13px 16px;border-radius:100px;
    box-shadow:0 14px 34px -12px rgba(31,68,52,.55);transition:transform .25s cubic-bezier(.22,.61,.36,1),background .25s;}
  .cbc-launch:hover{transform:translateY(-2px);background:#3A6B52;}
  .cbc-launch svg{width:20px;height:20px;flex:none;}
  .cbc-launch .cbc-dot{position:absolute;top:-3px;right:-3px;width:14px;height:14px;border-radius:50%;
    background:#C08A3E;border:2px solid #F4EFE3;display:none;}
  .cbc-launch.has-unread .cbc-dot{display:block;}
  .cbc-launch.hide{display:none;}

  .cbc-panel{position:fixed;right:24px;bottom:24px;z-index:151;width:370px;max-width:calc(100vw - 32px);
    height:560px;max-height:calc(100vh - 40px);background:#F4EFE3;border:1px solid #D8CDB4;border-radius:14px;
    box-shadow:0 30px 70px -24px rgba(22,53,42,.5);display:none;flex-direction:column;overflow:hidden;
    font-family:'Outfit',system-ui,sans-serif;}
  .cbc-panel.open{display:flex;animation:cbcIn .28s cubic-bezier(.22,.61,.36,1);}
  @keyframes cbcIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
  .cbc-head{background:#1F4434;color:#FBF9F3;padding:18px 20px;display:flex;align-items:center;gap:12px;}
  .cbc-head .cbc-avatar{width:38px;height:38px;border-radius:50%;background:#3A6B52;display:flex;align-items:center;
    justify-content:center;font-family:'Cormorant Garamond',serif;font-size:20px;color:#D9B98B;flex:none;}
  .cbc-head h4{font-family:'Cormorant Garamond',serif;font-weight:500;font-size:19px;margin:0;line-height:1.1;color:#FBF9F3 !important;-webkit-text-fill-color:#FBF9F3;}
  .cbc-head p{font-size:11px;color:rgba(255,255,255,.62) !important;-webkit-text-fill-color:rgba(255,255,255,.62);margin:2px 0 0;letter-spacing:.02em;}
  .cbc-close{margin-left:auto;background:none;border:none;color:rgba(255,255,255,.7);cursor:pointer;padding:4px;line-height:0;}
  .cbc-close:hover{color:#fff;}

  .cbc-body{flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:12px;background:#F4EFE3;}
  .cbc-intro{background:#FBF9F3;border:1px solid #E6DDC8;border-radius:10px;padding:16px 18px;color:#5E665C;font-size:13.5px;line-height:1.6;}
  .cbc-intro strong{color:#232A24;font-weight:500;}
  .cbc-msg{max-width:82%;padding:11px 15px;border-radius:14px;font-size:14px;line-height:1.55;white-space:pre-wrap;word-wrap:break-word;}
  .cbc-msg.visitor{align-self:flex-end;background:#1F4434;color:#FBF9F3;border-bottom-right-radius:4px;}
  .cbc-msg.admin{align-self:flex-start;background:#FBF9F3;color:#232A24;border:1px solid #E6DDC8;border-bottom-left-radius:4px;}
  .cbc-meta{font-size:10px;color:#8E948A;letter-spacing:.06em;margin:-4px 2px 2px;}
  .cbc-meta.visitor{align-self:flex-end;} .cbc-meta.admin{align-self:flex-start;}
  .cbc-auto-cta{align-self:flex-start;margin:-4px 0 2px;}
  .cbc-auto-btn{background:none;border:1px solid #C08A3E;color:#A6712B;font-family:'Outfit',system-ui,sans-serif;
    font-size:12px;font-weight:500;letter-spacing:.01em;padding:7px 13px;border-radius:100px;cursor:pointer;transition:background .18s,color .18s;}
  .cbc-auto-btn:hover{background:#C08A3E;color:#fff;}

  .cbc-foot{border-top:1px solid #E6DDC8;background:#FBF9F3;padding:14px;}
  .cbc-legal{background:#FBF9F3;padding:0 14px 10px;text-align:center;}
  .cbc-legal a{font-size:10.5px;color:#8E948A;text-decoration:none;letter-spacing:.02em;}
  .cbc-legal a:hover{color:#5E665C;text-decoration:underline;}
  .cbc-form{display:flex;flex-direction:column;gap:10px;}
  .cbc-form input,.cbc-form textarea,.cbc-row textarea{width:100%;font-family:'Outfit',system-ui,sans-serif;font-size:16px;color:#232A24;-webkit-text-fill-color:#232A24;background:#F4EFE3;
    border:1px solid #D8CDB4;border-radius:8px;padding:11px 13px;outline:none;transition:border-color .2s;box-sizing:border-box;}
  .cbc-form input:focus,.cbc-form textarea:focus,.cbc-row textarea:focus{border-color:#C08A3E;}
  .cbc-form input::placeholder,.cbc-form textarea::placeholder,.cbc-row textarea::placeholder{color:#9AA096;-webkit-text-fill-color:#9AA096;opacity:1;}
  .cbc-form textarea,.cbc-row textarea{resize:none;min-height:44px;max-height:120px;}
  #cbcTurnstile{max-width:100%;overflow:hidden;}
  .cbc-row{display:flex;gap:9px;align-items:flex-end;}
  .cbc-send{flex:none;background:#C08A3E;color:#fff;border:none;border-radius:8px;width:44px;height:44px;cursor:pointer;
    display:flex;align-items:center;justify-content:center;transition:background .2s,transform .15s;}
  .cbc-send:hover{background:#A6712B;transform:translateY(-1px);}
  .cbc-send:disabled{opacity:.5;cursor:default;transform:none;}
  .cbc-send svg{width:18px;height:18px;}
  .cbc-btn{background:#1F4434;color:#fff;border:none;border-radius:8px;padding:12px;font-family:inherit;font-size:12px;
    letter-spacing:.14em;text-transform:uppercase;font-weight:500;cursor:pointer;transition:background .2s;}
  .cbc-btn:hover{background:#3A6B52;}
  .cbc-hint{font-size:11px;color:#8E948A;text-align:center;margin-top:8px;}
  @media (max-width:480px){ .cbc-panel{right:8px;bottom:8px;left:8px;width:auto;height:460px;max-height:calc(100vh - 100px);} .cbc-launch{right:16px;bottom:16px;} }
  `;

  var style = document.createElement('style'); style.textContent = css; document.head.appendChild(style);

  var launch = document.createElement('button');
  launch.className = 'cbc-launch';
  launch.setAttribute('aria-label', 'Open chat');
  launch.innerHTML =
    '<span class="cbc-dot"></span>' +
    '<svg viewBox="0 0 24 24" fill="none"><path d="M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v9A1.5 1.5 0 0 1 18.5 16H9l-4 3.5V16H5.5A1.5 1.5 0 0 1 4 14.5v-9Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>' +
    '<span class="cbc-launch-label">'+cfg.chat_launcher_text+'</span>';

  var panel = document.createElement('div');
  panel.className = 'cbc-panel';
  panel.innerHTML =
    '<div class="cbc-head">' +
      '<div class="cbc-avatar">C</div>' +
      '<div><h4>CEIBA</h4><p class="cbc-subtitle">'+cfg.chat_subtitle+'</p></div>' +
      '<button class="cbc-close" aria-label="Close">' +
      '<svg viewBox="0 0 24 24" width="20" height="20" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button>' +
    '</div>' +
    '<div class="cbc-body" id="cbcBody"></div>' +
    '<div class="cbc-foot" id="cbcFoot"></div>' +
    '<div class="cbc-legal"><a href="/privacy.html" target="_blank" rel="noopener">Privacy Policy</a></div>';

  document.body.appendChild(launch);
  document.body.appendChild(panel);

  var body = panel.querySelector('#cbcBody');
  var foot = panel.querySelector('#cbcFoot');

  function esc(s){ return (s||'').replace(/[&<>]/g, function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];}); }
  function time(iso){ try{ return new Date((iso||'').replace(' ','T')+'Z').toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});}catch(e){return '';} }

  function msgHtml(m){
    var html = '<div class="cbc-meta '+m.sender+'">'+(m.sender==='admin'?'CEIBA':'You')+' &middot; '+time(m.created_at)+'</div>'+
               '<div class="cbc-msg '+m.sender+'">'+esc(m.body)+'</div>';
    if (m.is_auto){
      html += '<div class="cbc-auto-cta"><button type="button" class="cbc-auto-btn" data-auto-cta>'+esc(cfg.chat_auto_cta)+'</button></div>';
    }
    return html;
  }

  // Delegated: the auto-notice CTA is inserted long after this listener is
  // bound, so it has to be delegated rather than attached per-button.
  body.addEventListener('click', function(e){
    var btn = e.target.closest && e.target.closest('[data-auto-cta]');
    if (btn && window.openBooking) window.openBooking('');
  });

  function renderMessages(msgs){
    var intro = '<div class="cbc-intro">'+esc(cfg.chat_intro)+'</div>';
    body.innerHTML = intro + msgs.map(msgHtml).join('');
    body.scrollTop = body.scrollHeight;
    msgs.forEach(function(m){ seenIds.add(m.id); });
    if (msgs.length){ lastId = msgs[msgs.length-1].id; localStorage.setItem(LS_SEEN, lastId); }
  }

  function renderPrechat(){
    // Step 1: just name + email, kept deliberately uncluttered so it fits
    // cleanly on a small panel. The greeting message and the "how can we
    // help" field are deferred to step 2, once we know who's asking.
    body.innerHTML = '';
    foot.innerHTML =
      '<div class="cbc-form">' +
      '<input id="cbcName" type="text" placeholder="Your name" autocomplete="name" />' +
      '<input id="cbcEmail" type="email" placeholder="Email (so we can reply if you leave)" autocomplete="email" />' +
      '<div id="cbcStep1Err" style="color:#9B3B2E;font-size:12px;min-height:14px;"></div>' +
      '<button class="cbc-btn" id="cbcContinue">Continue</button>' +
      '</div>';
    foot.querySelector('#cbcContinue').addEventListener('click', goToPrechatStep2);
    foot.querySelector('#cbcEmail').addEventListener('keydown', function(e){
      if(e.key==='Enter'){ e.preventDefault(); goToPrechatStep2(); }
    });
    foot.querySelector('#cbcName').focus();
  }

  function goToPrechatStep2(){
    var nameEl = foot.querySelector('#cbcName');
    var name = (nameEl.value||'').trim();
    var errEl = foot.querySelector('#cbcStep1Err');
    if (!name){ if(errEl) errEl.textContent = 'Please enter your name.'; nameEl.focus(); return; }
    prechatName = name;
    prechatEmail = (foot.querySelector('#cbcEmail').value||'').trim();
    renderPrechatStep2();
  }

  function renderPrechatStep2(){
    var intro = '<div class="cbc-intro">'+esc(cfg.chat_intro)+'</div>';
    body.innerHTML = intro;
    body.scrollTop = 0;
    foot.innerHTML =
      '<div class="cbc-form">' +
      '<textarea id="cbcFirst" placeholder="How can we help?"></textarea>' +
      '<div id="cbcTurnstile"></div>' +
      '<div id="cbcErr" style="color:#9B3B2E;font-size:12px;min-height:14px;"></div>' +
      '<button class="cbc-btn" id="cbcStart">Start the conversation</button>' +
      '</div>';
    foot.querySelector('#cbcStart').addEventListener('click', startThread);
    foot.querySelector('#cbcFirst').addEventListener('keydown', function(e){
      if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); startThread(); }
    });
    renderChatTurnstile();
    foot.querySelector('#cbcFirst').focus();
  }

  function renderChatTurnstile(){
    cbcTurnstileId = null;
    function doRender(){
      var el = foot.querySelector('#cbcTurnstile');
      if (!el || !window.turnstile) return;
      cbcTurnstileId = turnstile.render(el, { sitekey: TURNSTILE_SITEKEY });
    }
    if (window.turnstile) doRender();
    else {
      var iv = setInterval(function(){ if (window.turnstile){ clearInterval(iv); doRender(); } }, 150);
    }
  }

  function renderComposer(){
    foot.innerHTML =
      '<div class="cbc-row">' +
      '<textarea id="cbcInput" placeholder="Write a message…" rows="1"></textarea>' +
      '<button class="cbc-send" id="cbcSend" aria-label="Send">' +
      '<svg viewBox="0 0 24 24" fill="none"><path d="M4 12l16-8-6 8 6 8-16-8Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg></button>' +
      '</div>';
    var input = foot.querySelector('#cbcInput');
    input.addEventListener('input', function(){ input.style.height='auto'; input.style.height=Math.min(input.scrollHeight,120)+'px'; });
    input.addEventListener('keydown', function(e){ if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); sendMsg(); } });
    foot.querySelector('#cbcSend').addEventListener('click', sendMsg);
    input.focus();
  }

  function api(path, opts){ return fetch(path, Object.assign({headers:{'content-type':'application/json'}}, opts)).then(function(r){return r.json();}); }

  function loadThread(){
    return api('/api/chat/thread', {method:'POST', body: JSON.stringify({token: token})}).then(function(d){
      token = d.token; localStorage.setItem(LS_TOKEN, token);
      renderMessages(d.messages || []);
      if ((d.messages||[]).length){ started = true; renderComposer(); } else { renderPrechat(); }
    });
  }

  function startThread(){
    var first = (foot.querySelector('#cbcFirst').value||'').trim();
    if (!first){ foot.querySelector('#cbcFirst').focus(); return; }
    var errEl = foot.querySelector('#cbcErr');
    var startBtn = foot.querySelector('#cbcStart');
    if (errEl) errEl.textContent = '';
    if (startBtn) startBtn.disabled = true;
    var tsToken = (window.turnstile && cbcTurnstileId != null) ? turnstile.getResponse(cbcTurnstileId) : '';
    api('/api/chat/thread', {method:'POST', body: JSON.stringify({token: token, name: prechatName, email: prechatEmail, turnstileToken: tsToken})}).then(function(d){
      if (d && d.error) throw new Error(d.error);
      token = d.token; localStorage.setItem(LS_TOKEN, token); started = true;
      return api('/api/chat/send', {method:'POST', body: JSON.stringify({token: token, body: first})});
    }).then(function(){ renderComposer(); return loadThread(); }).catch(function(e){
      if (startBtn) startBtn.disabled = false;
      if (window.turnstile && cbcTurnstileId != null) turnstile.reset(cbcTurnstileId);
      if (errEl) errEl.textContent = (e && e.message) || 'Something went wrong. Please try again.';
    });
  }

  function sendMsg(){
    var input = foot.querySelector('#cbcInput');
    var val = (input.value||'').trim(); if(!val) return;
    var btn = foot.querySelector('#cbcSend'); btn.disabled = true;
    // optimistic
    body.insertAdjacentHTML('beforeend', '<div class="cbc-meta visitor">You &middot; now</div><div class="cbc-msg visitor">'+esc(val)+'</div>');
    body.scrollTop = body.scrollHeight; input.value=''; input.style.height='auto';
    api('/api/chat/send', {method:'POST', body: JSON.stringify({token: token, body: val})}).then(function(d){
      if (d && d.id && d.id > lastId){ lastId = d.id; localStorage.setItem(LS_SEEN, lastId); }
      btn.disabled = false; poll();
    }).catch(function(){ btn.disabled = false; });
  }

  function poll(){
    if (!token) return Promise.resolve();
    return api('/api/chat/poll', {method:'POST', body: JSON.stringify({token: token, after: lastId})}).then(function(d){
      var msgs = d.messages || [];
      if (!msgs.length) return;
      msgs.forEach(function(m){
        if (seenIds.has(m.id)) return;
        if (m.sender === 'visitor' && m.id <= lastId) return;
        seenIds.add(m.id);
        body.insertAdjacentHTML('beforeend', msgHtml(m));
        lastId = m.id;
      });
      localStorage.setItem(LS_SEEN, lastId);
      body.scrollTop = body.scrollHeight;
      if (!open && msgs.some(function(m){return m.sender==='admin';})) launch.classList.add('has-unread');
    }).catch(function(){});
  }

  function openPanel(){
    open = true; panel.classList.add('open'); launch.classList.add('hide'); launch.classList.remove('has-unread');
    if (!started && !token){ renderPrechat(); }
    loadThread().then(function(){ clearInterval(pollTimer); pollTimer = setInterval(poll, 4000); });
  }
  function closePanel(){
    open = false; panel.classList.remove('open'); launch.classList.remove('hide');
    clearInterval(pollTimer); pollTimer = setInterval(bgPoll, 20000);
  }
  function bgPoll(){ if(!open) poll(); }

  launch.addEventListener('click', openPanel);
  panel.querySelector('.cbc-close').addEventListener('click', closePanel);

  // Pull in CMS-edited wording. Progressive enhancement: the widget is
  // already fully usable with the defaults above, this just refreshes the
  // static labels and, if the panel hasn't been opened yet, the welcome
  // message will already be correct by the time renderMessages runs.
  fetch('/api/chat-config', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (d) {
    if (!d) return;
    for (var k in cfg) if (d[k]) cfg[k] = d[k];
    var label = launch.querySelector('.cbc-launch-label'); if (label) label.textContent = cfg.chat_launcher_text;
    var sub = panel.querySelector('.cbc-subtitle'); if (sub) sub.textContent = cfg.chat_subtitle;
  }).catch(function () {});

  // background unread check on load if a thread already exists
  if (token){ pollTimer = setInterval(bgPoll, 20000); setTimeout(poll, 1500); }
})();
