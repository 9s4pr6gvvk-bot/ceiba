/* CEIBA — populates on-page prices from the CMS. Falls back silently to
   whatever figure is already in the HTML if the request fails. */
(function () {
  function fmt(n) {
    var v = parseInt(n, 10);
    if (isNaN(v)) return null;
    return '£' + v.toLocaleString('en-GB');
  }
  fetch('/api/prices', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (p) {
    var map = {
      priceIndividual: fmt(p.price_individual),
      priceProgramme: fmt(p.price_programme),
      priceGroup: fmt(p.price_group),
      priceGroupWas: fmt(p.price_group_was),
    };
    Object.keys(map).forEach(function (id) {
      var el = document.getElementById(id);
      if (el && map[id]) el.textContent = map[id];
    });
  }).catch(function () {});
})();
