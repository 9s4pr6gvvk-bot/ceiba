// Availability engine for the CEIBA booking system.
//
// Slots are never pre-stored. We read the admin's availability settings and
// generate candidate slots on the fly, then subtract any already held by a
// pending/accepted booking. Computed in the configured timezone; slot_start is
// stored/compared as a minute-precision UTC ISO string.

const DEFAULTS = {
  booking_days: '1,2,3,4,5',
  booking_start: '09:00',
  booking_end: '17:00',
  booking_duration: '30',
  booking_buffer: '0',
  booking_lead_hours: '24',
  booking_horizon: '21',
  booking_timezone: 'Europe/London',
};

export async function getSettings(env) {
  const out = { ...DEFAULTS };
  try {
    const { results } = await env.DB.prepare(
      "SELECT key, value FROM app_settings WHERE key LIKE 'booking_%'"
    ).all();
    for (const r of results || []) out[r.key] = r.value;
  } catch { /* table may not exist yet; defaults are fine */ }
  return {
    days: (out.booking_days || '').split(',').map((s) => parseInt(s, 10)).filter((n) => !isNaN(n)),
    start: out.booking_start || '09:00',
    end: out.booking_end || '17:00',
    duration: Math.max(5, parseInt(out.booking_duration, 10) || 30),
    buffer: Math.max(0, parseInt(out.booking_buffer, 10) || 0),
    leadHours: Math.max(0, parseInt(out.booking_lead_hours, 10) || 0),
    horizon: Math.min(120, Math.max(1, parseInt(out.booking_horizon, 10) || 21)),
    timezone: out.booking_timezone || 'Europe/London',
  };
}

function tzParts(date, timeZone) {
  const fmt = new Intl.DateTimeFormat('en-GB', {
    timeZone, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, weekday: 'short',
  });
  const p = {};
  for (const part of fmt.formatToParts(date)) p[part.type] = part.value;
  return p;
}

function tzOffsetMinutes(date, timeZone) {
  const p = tzParts(date, timeZone);
  const asUTC = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second);
  return Math.round((asUTC - date.getTime()) / 60000);
}

function wallToUTC(y, m, d, hh, mm, timeZone) {
  let guess = new Date(Date.UTC(y, m - 1, d, hh, mm));
  const off = tzOffsetMinutes(guess, timeZone);
  return new Date(guess.getTime() - off * 60000);
}

function hm(str) {
  const [h, m] = (str || '0:0').split(':').map((n) => parseInt(n, 10) || 0);
  return h * 60 + m;
}

export async function computeAvailability(env, settings) {
  const s = settings || (await getSettings(env));
  const now = new Date();
  const earliest = new Date(now.getTime() + s.leadHours * 3600 * 1000);

  const taken = new Set();
  try {
    const { results } = await env.DB.prepare(
      "SELECT slot_start FROM bookings WHERE status IN ('pending','accepted')"
    ).all();
    for (const r of results || []) taken.add(r.slot_start);
  } catch { /* table may not exist yet */ }

  const startMin = hm(s.start);
  const endMin = hm(s.end);
  const step = s.duration + s.buffer;

  const days = [];
  for (let i = 0; i <= s.horizon; i++) {
    const dayAnchor = new Date(now.getTime() + i * 86400000);
    const p = tzParts(dayAnchor, s.timezone);
    const y = +p.year, mo = +p.month, d = +p.day;
    const dow = new Date(Date.UTC(y, mo - 1, d)).getUTCDay();
    if (!s.days.includes(dow)) continue;

    const slots = [];
    for (let t = startMin; t + s.duration <= endMin; t += step) {
      const hh = Math.floor(t / 60), mm = t % 60;
      const utc = wallToUTC(y, mo, d, hh, mm, s.timezone);
      if (utc < earliest) continue;
      const iso = utcIso(utc);
      if (taken.has(iso)) continue;
      slots.push({ start: iso, label: timeLabel(utc, s.timezone) });
    }
    if (slots.length) {
      days.push({ date: `${y}-${pad(mo)}-${pad(d)}`, label: dayLabel(dayAnchor, s.timezone), slots });
    }
  }
  return days;
}

export async function isSlotBookable(env, isoStart, settings) {
  const days = await computeAvailability(env, settings);
  for (const day of days) {
    for (const slot of day.slots) {
      if (slot.start === isoStart) return true;
    }
  }
  return false;
}

function pad(n) { return String(n).padStart(2, '0'); }

function utcIso(date) {
  return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())}T${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}`;
}

function timeLabel(date, timeZone) {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone, hour: 'numeric', minute: '2-digit', hour12: true,
  }).format(date).replace(/\s?([ap])m/i, (m, g) => ' ' + g.toLowerCase() + 'm');
}

function dayLabel(date, timeZone) {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone, weekday: 'short', day: 'numeric', month: 'short',
  }).format(date);
}

export function formatSlot(isoStart, timeZone = 'Europe/London') {
  const d = new Date(isoStart + (isoStart.endsWith('Z') ? '' : 'Z'));
  const date = new Intl.DateTimeFormat('en-GB', {
    timeZone, weekday: 'short', day: 'numeric', month: 'short', year: 'numeric',
  }).format(d);
  const time = timeLabel(d, timeZone);
  return `${date}, ${time}`;
}

// Self-healing: create the booking tables + default settings if they don't
// exist yet. Cheap (IF NOT EXISTS) and means the feature works without a
// separate manual migration step.
export async function ensureBookingTables(env) {
  await env.DB.exec(
    "CREATE TABLE IF NOT EXISTS bookings (id INTEGER PRIMARY KEY AUTOINCREMENT, token TEXT NOT NULL UNIQUE, name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT DEFAULT '', service TEXT DEFAULT '', slot_start TEXT NOT NULL, duration_min INTEGER DEFAULT 30, note TEXT DEFAULT '', status TEXT DEFAULT 'pending', admin_note TEXT DEFAULT '', seen_by_admin INTEGER DEFAULT 0, created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now')))"
  );
  await env.DB.exec("CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT DEFAULT '', updated_at TEXT DEFAULT (datetime('now')))");
}
