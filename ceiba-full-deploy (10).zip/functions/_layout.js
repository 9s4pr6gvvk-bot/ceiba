// Server-rendered page shell for the CEIBA Journal (blog), matching the site's
// design tokens, nav and footer. Content pages use a compact solid nav (there's
// no hero image behind it), which is the right call for reading pages.

const LOGO_STACKED = 'https://raw.githubusercontent.com/9s4pr6gvvk-bot/ceiba/refs/heads/main/Ceiba%20logo%20stacked%202%20(1).png';
const LOGO_FLAT = 'https://raw.githubusercontent.com/9s4pr6gvvk-bot/ceiba/refs/heads/main/Ceiba%20not%20stacked%20png.png';
const ORIGIN = 'https://ceibamethod.co.uk'; // used for canonical / og

export function shell({ title, description, canonical, ogImage, bodyClass = '', content }) {
  const desc = (description || 'CEIBA — transformational coaching for life transitions and change.').replace(/"/g, '&quot;');
  const canon = canonical || ORIGIN;
  const og = ogImage || LOGO_STACKED;
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>${title}</title>
<meta name="description" content="${desc}" />
<link rel="canonical" href="${canon}" />
<meta property="og:type" content="article" />
<meta property="og:title" content="${title.replace(/"/g, '&quot;')}" />
<meta property="og:description" content="${desc}" />
<meta property="og:image" content="${og}" />
<meta property="og:url" content="${canon}" />
<meta name="twitter:card" content="summary_large_image" />
<link rel="stylesheet" href="/assets/fonts/fonts.css" />
<style>
  *,*::before,*::after{ box-sizing:border-box; margin:0; padding:0; }
  :root{
    --bg:#F4EFE3; --bg-warm:#EFE8D8; --bg-alt:#EAE2CE; --white:#FBF9F3;
    --forest:#1F4434; --forest-deep:#16352A; --forest-mid:#3A6B52;
    --sage:#9CBBA4; --sage-soft:#C3D4C4; --text:#232A24; --muted:#5E665C;
    --subtle:#8E948A; --border:#D8CDB4; --border-lt:#E6DDC8;
    --gold:#C08A3E; --gold-deep:#A6712B; --gold-soft:#D9B98B;
    --max:1240px; --measure:720px; --ease:cubic-bezier(.22,.61,.36,1);
  }
  html{ scroll-behavior:smooth; }
  body{ font-family:'Outfit',sans-serif; font-weight:300; background:var(--bg); color:var(--text); line-height:1.75; -webkit-font-smoothing:antialiased; text-rendering:optimizeLegibility; }
  h1,h2,h3,h4{ font-family:'Cormorant Garamond',serif; font-weight:500; color:var(--text); line-height:1.14; }
  em{ font-style:italic; color:var(--gold); }
  a{ color:inherit; }
  img{ display:block; max-width:100%; }
  ::selection{ background:var(--sage); color:var(--forest-deep); }
  .wrap{ max-width:var(--max); margin:0 auto; padding:0 40px; }
  .kicker{ display:inline-flex; align-items:center; gap:11px; font-size:11px; letter-spacing:.28em; text-transform:uppercase; color:var(--gold-deep); font-weight:500; margin-bottom:20px; }
  .kicker::before{ content:''; width:26px; height:1px; background:var(--gold); opacity:.6; }

  /* util bar */
  .util{ background:var(--forest-deep); color:rgba(255,255,255,.62); font-size:11.5px; letter-spacing:.08em; }
  .util-in{ max-width:var(--max); margin:0 auto; padding:8px 40px; display:flex; justify-content:space-between; align-items:center; gap:20px; }
  .util a{ color:rgba(255,255,255,.82); text-decoration:none; transition:color .2s; }
  .util a:hover{ color:#fff; }
  .util-tag{ text-transform:uppercase; letter-spacing:.18em; font-size:10px; color:var(--gold-soft); }
  .util-right{ display:flex; gap:22px; align-items:center; }

  /* compact solid nav */
  nav.main{ position:sticky; top:0; z-index:100; background:rgba(244,239,227,.97); backdrop-filter:blur(14px); -webkit-backdrop-filter:blur(14px); border-bottom:1px solid var(--border); }
  .nav-inner{ max-width:var(--max); margin:0 auto; padding:0 40px; height:96px; display:flex; align-items:center; justify-content:space-between; gap:26px; }
  .brand{ display:flex; align-items:center; text-decoration:none; }
  .brand img{ height:64px; width:auto; }
  .nav-links{ display:flex; list-style:none; gap:22px; align-items:center; }
  .nav-links a{ position:relative; font-size:11.5px; font-weight:500; letter-spacing:.13em; text-transform:uppercase; white-space:nowrap; color:var(--muted); text-decoration:none; transition:color .25s; }
  .nav-links a::after{ content:''; position:absolute; left:0; right:100%; bottom:-4px; height:1.5px; background:var(--gold); transition:right .3s var(--ease); }
  .nav-links a:hover{ color:var(--text); } .nav-links a:hover::after{ right:0; }
  .nav-links a.active{ color:var(--forest); } .nav-links a.active::after{ right:0; }
  .nav-cta{ background:var(--forest); color:#fff !important; padding:12px 24px; font-size:11px; letter-spacing:.13em; text-transform:uppercase; font-weight:500; text-decoration:none; border-radius:2px; transition:background .25s, transform .2s var(--ease); white-space:nowrap; }
  .nav-cta::after{ display:none; }
  .nav-cta:hover{ background:var(--forest-mid); transform:translateY(-2px); }
  .nav-links li.has-drop{ position:relative; }
  .nav-links li.has-drop > a .chev{ display:inline-block; margin-left:5px; opacity:.5; font-style:normal; transition:transform .22s var(--ease); }
  .nav-links li.has-drop:hover > a .chev{ transform:rotate(180deg); }
  .nav-links li.has-drop > a::after{ display:none !important; }
  .nav-drop{ position:absolute; top:calc(100% + 6px); left:50%; transform:translateX(-50%) translateY(4px); min-width:200px; background:var(--white); border:1px solid var(--border); border-radius:4px; box-shadow:0 16px 40px -12px rgba(31,68,52,.18); padding:8px 0; opacity:0; pointer-events:none; transition:opacity .22s var(--ease), transform .22s var(--ease); z-index:200; }
  .nav-drop::before{ content:''; position:absolute; top:-12px; left:0; right:0; height:12px; }
  .nav-links li.has-drop:hover .nav-drop,
  .nav-links li.has-drop:focus-within .nav-drop{ opacity:1; pointer-events:auto; transform:translateX(-50%) translateY(0); }
  .nav-drop a{ display:block; padding:10px 20px; font-size:11px; letter-spacing:.13em; text-transform:uppercase; color:var(--muted); text-decoration:none; font-weight:500; white-space:nowrap; transition:color .2s, background .2s; }
  .nav-drop a::after{ display:none !important; }
  .nav-drop a:hover{ color:var(--forest); background:var(--bg); }
  /* ── HAMBURGER ── */
  .hamburger{ display:none; flex-direction:column; justify-content:center; gap:5px; cursor:pointer; padding:8px; background:none; border:none; width:40px; height:40px; }
  .hamburger span{ display:block; width:22px; height:1.5px; background:var(--text); transition:transform .3s cubic-bezier(.22,.61,.36,1), opacity .3s; transform-origin:center; }
  .hamburger.open span:nth-child(1){ transform:translateY(6.5px) rotate(45deg); }
  .hamburger.open span:nth-child(2){ opacity:0; transform:scaleX(0); }
  .hamburger.open span:nth-child(3){ transform:translateY(-6.5px) rotate(-45deg); }
  /* ── MOBILE DRAWER ── */
  .mob-scrim{ display:none; position:fixed; inset:0; background:rgba(17,28,22,.55); z-index:190; backdrop-filter:blur(2px); -webkit-backdrop-filter:blur(2px); opacity:0; transition:opacity .35s ease; }
  .mob-scrim.open{ display:block; opacity:1; }
  .mob-menu{ position:fixed; top:0; right:0; bottom:0; width:min(360px,92vw); background:var(--forest-deep); z-index:200; display:flex; flex-direction:column; transform:translateX(100%); transition:transform .38s cubic-bezier(.22,.61,.36,1); overflow-y:auto; }
  .mob-menu.open{ transform:translateX(0); }
  .mob-header{ display:flex; align-items:center; justify-content:space-between; padding:20px 24px; border-bottom:1px solid rgba(255,255,255,.08); flex-shrink:0; }
  .mob-logo{ height:40px; width:auto; filter:brightness(0) invert(1) opacity(.9); }
  .mob-close{ background:none; border:1px solid rgba(255,255,255,.2); border-radius:50%; color:rgba(255,255,255,.7); width:36px; height:36px; display:flex; align-items:center; justify-content:center; cursor:pointer; font-size:20px; line-height:1; transition:border-color .2s, color .2s; flex-shrink:0; }
  .mob-close:hover{ border-color:var(--gold-soft); color:#fff; }
  .mob-nav{ flex:1; padding:8px 0 24px; display:flex; flex-direction:column; }
  .mob-nav a{ display:block; padding:14px 28px; font-family:'Outfit',sans-serif; font-size:.95rem; font-weight:400; letter-spacing:.04em; color:rgba(255,255,255,.78); text-decoration:none; transition:color .2s, background .2s; border-left:2px solid transparent; }
  .mob-nav a:hover,.mob-nav a.mob-active{ color:#fff; background:rgba(255,255,255,.04); border-left-color:var(--gold); }
  .mob-divider{ height:1px; background:rgba(255,255,255,.08); margin:8px 28px; }
  .mob-section-label{ display:block; font-size:10px; letter-spacing:.22em; text-transform:uppercase; color:var(--gold-soft); padding:16px 28px 6px; font-weight:500; opacity:.7; }
  .mob-sub-link{ padding-left:40px !important; font-size:.88rem !important; color:rgba(255,255,255,.55) !important; }
  .mob-sub-link:hover{ color:rgba(255,255,255,.9) !important; }
  .mob-footer{ padding:20px 24px; border-top:1px solid rgba(255,255,255,.08); flex-shrink:0; }
  .mob-nav-btn{ display:block; width:100%; text-align:left; padding:14px 28px; font-family:'Outfit',sans-serif; font-size:.95rem; font-weight:400; letter-spacing:.04em; color:rgba(255,255,255,.78); background:none; border:none; border-left:2px solid transparent; cursor:pointer; transition:color .2s, background .2s; }
  .mob-nav-btn:hover{ color:#fff; background:rgba(255,255,255,.04); border-left-color:var(--gold); }
  .mob-cta-btn{ display:block; width:100%; text-align:center; background:var(--gold); color:#fff; font-family:'Outfit',sans-serif; font-size:11px; letter-spacing:.16em; text-transform:uppercase; font-weight:500; padding:16px 24px; border-radius:2px; border:none; cursor:pointer; transition:background .25s; text-decoration:none; }
  .mob-cta-btn:hover{ background:var(--gold-deep); }
  @media (max-width:900px){ .nav-links,.nav-cta{ display:none; } .hamburger{ display:flex; } .brand img{ height:52px; } .nav-inner{ height:78px; } }
  @media (max-width:640px){ .util-in{ padding:7px 20px; font-size:10.5px; } .util-tag{ display:none; } }

  /* article + list */
  .page-head{ padding:78px 0 34px; text-align:center; }
  .page-head h1{ font-size:clamp(2.6rem,6vw,4.3rem); letter-spacing:-.01em; }
  .page-head p.lede{ max-width:600px; margin:18px auto 0; color:var(--muted); font-size:15.5px; }
  .crumbs{ font-size:11px; letter-spacing:.14em; text-transform:uppercase; color:var(--subtle); margin-bottom:22px; }
  .crumbs a{ color:var(--muted); text-decoration:none; } .crumbs a:hover{ color:var(--gold-deep); }

  .post-grid{ display:grid; grid-template-columns:repeat(auto-fill,minmax(320px,1fr)); gap:34px; padding:12px 0 90px; }
  .post-card{ background:var(--white); border:1px solid var(--border-lt); border-radius:6px; overflow:hidden; text-decoration:none; color:inherit; display:flex; flex-direction:column; transition:transform .3s var(--ease), box-shadow .3s var(--ease), border-color .3s; }
  .post-card:hover{ transform:translateY(-4px); box-shadow:0 22px 44px -24px rgba(31,68,52,.32); border-color:var(--border); }
  .post-card .cover{ aspect-ratio:16/10; background:var(--bg-alt) center/cover no-repeat; }
  .post-card .body{ padding:26px 26px 30px; display:flex; flex-direction:column; gap:11px; flex:1; }
  .post-card .date{ font-size:10.5px; letter-spacing:.16em; text-transform:uppercase; color:var(--gold-deep); }
  .post-card h3{ font-size:1.55rem; }
  .post-card p{ color:var(--muted); font-size:14px; line-height:1.7; }
  .post-card .more{ margin-top:auto; font-size:11px; letter-spacing:.16em; text-transform:uppercase; color:var(--forest); font-weight:500; display:inline-flex; align-items:center; gap:9px; }
  .post-card .more .ln{ width:26px; height:1px; background:var(--gold); transition:width .3s var(--ease); }
  .post-card:hover .more .ln{ width:40px; }

  .empty{ text-align:center; color:var(--muted); padding:40px 0 100px; }

  article.post{ max-width:var(--measure); margin:0 auto; padding:8px 40px 90px; }
  article.post .date{ font-size:11px; letter-spacing:.16em; text-transform:uppercase; color:var(--gold-deep); margin-bottom:14px; display:block; text-align:center; }
  article.post h1{ font-size:clamp(2.3rem,5.4vw,3.7rem); text-align:center; letter-spacing:-.01em; }
  article.post .excerpt{ text-align:center; color:var(--muted); font-size:16px; margin:20px auto 0; max-width:600px; }
  article.post .cover{ width:100%; aspect-ratio:16/9; object-fit:cover; border-radius:6px; margin:46px 0; }
  .prose{ font-size:16.5px; color:var(--text); line-height:1.9; }
  .prose > * + *{ margin-top:1.25em; }
  .prose h2{ font-size:2rem; margin-top:1.8em; }
  .prose h3{ font-size:1.55rem; margin-top:1.5em; }
  .prose p{ font-weight:300; }
  .prose a{ color:var(--gold-deep); text-decoration:underline; text-underline-offset:3px; text-decoration-thickness:1px; }
  .prose blockquote{ border-left:2px solid var(--gold); padding:6px 0 6px 26px; font-family:'Cormorant Garamond',serif; font-style:italic; font-size:1.5rem; line-height:1.4; color:var(--forest-mid); }
  .prose ul,.prose ol{ padding-left:1.3em; } .prose li{ margin:.4em 0; }
  .prose img{ border-radius:6px; margin:1.6em 0; }
  .prose code{ background:var(--bg-alt); padding:2px 7px; border-radius:3px; font-size:.9em; }
  .prose pre{ background:var(--forest-deep); color:#EFE8D8; padding:20px 22px; border-radius:6px; overflow:auto; }
  .prose pre code{ background:none; padding:0; color:inherit; }
  .prose hr{ border:none; border-top:1px solid var(--border); margin:2.4em 0; }
  .post-foot{ max-width:var(--measure); margin:0 auto; padding:0 40px 100px; text-align:center; }
  .post-foot .divider{ width:60px; height:1px; background:var(--gold); margin:0 auto 30px; }
  .btn{ display:inline-flex; align-items:center; justify-content:center; gap:10px; font-family:'Outfit',sans-serif; font-size:11px; letter-spacing:.16em; text-transform:uppercase; font-weight:500; text-decoration:none; padding:14px 30px; cursor:pointer; border:none; border-radius:2px; transition:background .25s,transform .2s var(--ease); }
  .btn-fill{ background:var(--forest); color:#fff; } .btn-fill:hover{ background:var(--forest-mid); transform:translateY(-2px); }
  .btn-ghost{ background:transparent; color:var(--forest); border:1px solid var(--border); } .btn-ghost:hover{ border-color:var(--gold); transform:translateY(-2px); }

  /* footer */
  footer{ background:var(--forest-deep); padding:76px 0 34px; }
  .footer-top{ max-width:var(--max); margin:0 auto; padding:0 40px 44px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:40px; border-bottom:1px solid rgba(255,255,255,.1); }
  .footer-brand{ display:flex; align-items:center; }
  .footer-logo{ height:auto; width:210px; display:block; filter:brightness(0) invert(1) opacity(.92); }
  .footer-nav{ display:flex; gap:26px; flex-wrap:wrap; align-items:center; }
  .footer-nav a{ font-size:11.5px; letter-spacing:.12em; text-transform:uppercase; color:rgba(255,255,255,.6); text-decoration:none; transition:color .2s; }
  .footer-nav a:hover{ color:#fff; }
  .footer-social{ display:flex; gap:12px; }
  .footer-social a{ width:38px; height:38px; border-radius:50%; border:1px solid rgba(255,255,255,.25); display:flex; align-items:center; justify-content:center; transition:border-color .25s,background .25s,transform .25s; }
  .footer-social a:hover{ background:rgba(255,255,255,.1); border-color:var(--gold-soft); transform:translateY(-2px); }
  .footer-social svg{ width:16px; height:16px; }
  .footer-bottom{ max-width:var(--max); margin:0 auto; padding:24px 40px 0; display:flex; justify-content:space-between; flex-wrap:wrap; gap:12px; font-size:11.5px; color:rgba(255,255,255,.42); }
  .footer-bottom a{ color:rgba(255,255,255,.42); text-decoration:none; } .footer-bottom a:hover{ color:#fff; }
</style>
</head>
<body class="${bodyClass}">
  <div class="util"><div class="util-in">
    <a href="mailto:gerry@ceibamethod.co.uk">gerry@ceibamethod.co.uk</a>
    <div class="util-right">
      <span class="util-tag">Clarity · Change · Possibility</span>
      <a href="#" data-open-modal>Book a Discovery Call →</a>
    </div>
  </div></div>

  <nav class="main">
    <div class="nav-inner">
      <a href="/index.html" class="brand" aria-label="CEIBA home"><img src="${LOGO_FLAT}" alt="CEIBA" /></a>
      <ul class="nav-links">
        <li><a href="/index.html">Home</a></li>
        <li><a href="/about.html">About</a></li>
        <li><a href="/index.html#method">The CEIBA Method</a></li>
        <li class="has-drop"><a href="/individuals.html">Work With Me <em class="chev">&#8964;</em></a>
          <div class="nav-drop">
            <a href="/individuals.html">For Individuals</a>
            <a href="/organisations.html">For Organisations</a>
            <a href="/groups.html">Group Programme</a>
          </div>
        </li>
        <li><a href="/blog" class="active">Journal</a></li>
        <li><a href="/index.html#contact">Contact</a></li>
      </ul>
      <a href="/index.html#contact" class="nav-cta">Book a Discovery Call</a>
      <button class="hamburger" id="layoutHamburger" aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button>
    </div>
  </nav>

  <div class="mob-scrim" id="layoutScrim"></div>
  <div class="mob-menu" id="layoutMobMenu" aria-hidden="true" role="dialog" aria-label="Navigation menu">
    <div class="mob-header">
      <img class="mob-logo" src="${LOGO_FLAT}" alt="CEIBA" />
      <button class="mob-close" id="layoutMobClose" aria-label="Close menu">&times;</button>
    </div>
    <nav class="mob-nav">
      <a href="/index.html">Home</a>
      <a href="/about.html">About</a>
      <a href="/index.html#method">The CEIBA Method</a>
      <div class="mob-divider"></div>
      <span class="mob-section-label">Work With Me</span>
      <a href="/individuals.html" class="mob-sub-link">For Individuals</a>
      <a href="/organisations.html" class="mob-sub-link">For Organisations</a>
      <a href="/groups.html" class="mob-sub-link">Group Programme</a>
      <div class="mob-divider"></div>
      <a href="/blog" class="mob-active">Journal</a>
      <button class="mob-nav-btn" id="layoutContactBtn">Contact</button>
    </nav>
    <div class="mob-footer">
      <a href="/index.html#contact" class="mob-cta-btn">Book a Discovery Call</a>
    </div>
  </div>

  ${content}

  <footer>
    <div class="footer-top">
      <div class="footer-brand">
        <a href="/index.html"><img src="${LOGO_STACKED}" alt="CEIBA — Transformational Coaching &amp; Change" class="footer-logo" /></a>
      </div>
      <nav class="footer-nav">
        <a href="/index.html">Home</a>
        <a href="/about.html">About</a>
        <a href="/index.html#method">The CEIBA Method</a>
        <a href="/individuals.html">Work With Me</a>
        <a href="/blog">Journal</a>
        <a href="/index.html#contact">Contact</a>
      </nav>
      <div class="footer-social">
        <a href="mailto:gerry@ceibamethod.co.uk" aria-label="Email"><svg viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2" stroke="#fff" stroke-width="1.3"/><path d="M4 7l8 6 8-6" stroke="#fff" stroke-width="1.3"/></svg></a>
        <a href="#" aria-label="LinkedIn"><svg viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="2" stroke="#fff" stroke-width="1.3"/><path d="M8 10.5V17M8 7.6v.01M12 17v-4.2c0-1.3 1-2.3 2.2-2.3s2.2 1 2.2 2.3V17M12 10.5V17" stroke="#fff" stroke-width="1.3" stroke-linecap="round"/></svg></a>
        <a href="#" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none"><rect x="3.5" y="3.5" width="17" height="17" rx="5" stroke="#fff" stroke-width="1.3"/><circle cx="12" cy="12" r="4" stroke="#fff" stroke-width="1.3"/><circle cx="17" cy="7" r="1" fill="#fff"/></svg></a>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; ${new Date().getFullYear()} CEIBA &middot; gerry@ceibamethod.co.uk</span>
      <span><a href="/privacy.html">Privacy Policy</a> &middot; <a href="/terms.html">Terms</a> &middot; <a href="https://www.franks-media.co.uk" target="_blank" rel="noopener">Website designed by Franks Media</a></span>
    </div>
  </footer>
  <script src="/assets/chat.js" defer></script>
  <script src="/assets/booking.js" defer></script>
  <script>
    /* ── MOBILE DRAWER ── */
    (function(){
      var hamburger = document.getElementById('layoutHamburger');
      var mobMenu   = document.getElementById('layoutMobMenu');
      var mobScrim  = document.getElementById('layoutScrim');
      var mobClose  = document.getElementById('layoutMobClose');
      if(!hamburger) return;
      function openMob(){ mobMenu.classList.add('open'); mobScrim.classList.add('open'); hamburger.classList.add('open'); hamburger.setAttribute('aria-expanded','true'); mobMenu.setAttribute('aria-hidden','false'); document.body.style.overflow='hidden'; }
      function closeMob(){ mobMenu.classList.remove('open'); mobScrim.classList.remove('open'); hamburger.classList.remove('open'); hamburger.setAttribute('aria-expanded','false'); mobMenu.setAttribute('aria-hidden','true'); document.body.style.overflow=''; }
      hamburger.addEventListener('click', openMob);
      mobClose.addEventListener('click', closeMob);
      mobScrim.addEventListener('click', closeMob);
      document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeMob(); });
      mobMenu.querySelectorAll('a').forEach(function(a){ a.addEventListener('click', closeMob); });
      var layoutContactBtn = document.getElementById('layoutContactBtn');
      if(layoutContactBtn){
        layoutContactBtn.addEventListener('click', function(){
          window.location.href='/index.html?to=contact';
        });
      }
    })();

    if (location.hash) {
      var h = location.hash;
      history.replaceState(null, '', location.pathname);
      window.addEventListener('load', function() {
        setTimeout(function() {
          var el = document.querySelector(h);
          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 120);
      });
    }
  </script>
</body>
</html>`;
}

export function fmtDate(iso) {
  if (!iso) return '';
  try {
    return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  } catch { return ''; }
}
