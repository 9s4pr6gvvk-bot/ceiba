// Shared helpers for CEIBA CMS Pages Functions.
// Files/dirs prefixed with "_" are never routed by Cloudflare Pages.

/* ---------- responses ---------- */
export const json = (data, status = 200, headers = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers },
  });

export const bad = (msg, status = 400) => json({ error: msg }, status);

/* ---------- Turnstile ---------- */
/* Verifies a Turnstile token against Cloudflare's siteverify endpoint.
   Returns true (no-op) if TURNSTILE_SECRET_KEY isn't configured yet, so the
   site keeps working before the widget is wired up. Once the secret is set,
   a missing/invalid token is rejected. */
export async function verifyTurnstile(request, env, token) {
  if (!env.TURNSTILE_SECRET_KEY) return true;
  if (!token) return false;
  try {
    const body = new URLSearchParams();
    body.set('secret', env.TURNSTILE_SECRET_KEY);
    body.set('response', token);
    const ip = request.headers.get('CF-Connecting-IP');
    if (ip) body.set('remoteip', ip);
    const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body });
    const data = await r.json();
    return !!data.success;
  } catch { return false; }
}

/* ---------- rate limiting ----------
   Fixed-window counter backed by D1 — no extra Cloudflare bindings needed,
   just the DB that's already bound everywhere else. Good enough to stop a
   script from hammering the public forms; it's not the edge-level rate
   limiting Cloudflare's dashboard offers for high-traffic APIs, but this
   site doesn't need that, and this keeps the whole thing in code/D1 rather
   than depending on a dashboard rule someone has to remember to configure. */
let _rateLimitTableReady = false;
async function ensureRateLimitTable(env) {
  if (_rateLimitTableReady) return;
  await env.DB.prepare(
    `CREATE TABLE IF NOT EXISTS rate_limits (
       bucket_key TEXT PRIMARY KEY,
       count INTEGER NOT NULL DEFAULT 0,
       expires_at INTEGER NOT NULL
     )`
  ).run();
  _rateLimitTableReady = true;
}

export function clientIp(request) {
  return request.headers.get('CF-Connecting-IP') || 'unknown';
}

/* Returns true if `key` has made more than `limit` calls in the current
   `windowSeconds` window, i.e. true means "reject this request". Buckets
   are keyed by window start, so old buckets just age out; a small fraction
   of calls also sweep expired rows so the table doesn't grow forever.
   Fails open (never blocks) if the check itself errors — a rate limiter
   bug shouldn't be able to take the site down. */
export async function rateLimited(env, key, limit, windowSeconds) {
  try {
    await ensureRateLimitTable(env);
    const now = Math.floor(Date.now() / 1000);
    const windowStart = now - (now % windowSeconds);
    const bucketKey = `${key}:${windowStart}`;
    const expiresAt = windowStart + windowSeconds;

    const row = await env.DB.prepare(
      `INSERT INTO rate_limits (bucket_key, count, expires_at) VALUES (?, 1, ?)
       ON CONFLICT(bucket_key) DO UPDATE SET count = count + 1
       RETURNING count`
    ).bind(bucketKey, expiresAt).first();

    if (Math.random() < 0.02) {
      await env.DB.prepare('DELETE FROM rate_limits WHERE expires_at < ?').bind(now).run();
    }

    return (row && row.count || 0) > limit;
  } catch {
    return false;
  }
}

export const tooManyRequests = () =>
  json({ error: 'Too many requests. Please try again shortly.' }, 429);

/* ---------- crypto ---------- */

export function getCookie(request, name) {
  const raw = request.headers.get('cookie') || '';
  const m = raw.match(new RegExp('(?:^|;\\s*)' + name + '=([^;]+)'));
  return m ? decodeURIComponent(m[1]) : null;
}

/* ---------- Cloudflare Access (Zero Trust) auth ----------
   /admin* is gated at the edge by a Cloudflare Access application, but
   Access only protects the page path itself — it does NOT protect the
   /api/* endpoints the admin panel calls underneath. Those are secured
   here instead, by verifying the CF_Authorization JWT cookie that Access
   sets once someone signs in. This replaces the old ADMIN_PASSWORD check. */
const ACCESS_TEAM_DOMAIN = 'orange-feather-2b28.cloudflareaccess.com';
const ACCESS_AUD = '2856b8725bc630f228e646c5defbe32b228d0414909c3515038ea7de700d079e';
const ACCESS_CERTS_URL = `https://${ACCESS_TEAM_DOMAIN}/cdn-cgi/access/certs`;
const ACCESS_ISSUER = `https://${ACCESS_TEAM_DOMAIN}`;

let _jwksCache = null, _jwksCacheAt = 0;
async function getAccessJWKS() {
  const now = Date.now();
  if (_jwksCache && (now - _jwksCacheAt) < 10 * 60 * 1000) return _jwksCache;
  const r = await fetch(ACCESS_CERTS_URL);
  const data = await r.json();
  _jwksCache = data.keys || [];
  _jwksCacheAt = now;
  return _jwksCache;
}

function b64urlToBytes(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  const bin = atob(s);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}
function b64urlToJson(s) {
  return JSON.parse(new TextDecoder().decode(b64urlToBytes(s)));
}

/* Verifies a Cloudflare Access JWT: signature, audience, issuer, expiry.
   Returns the decoded payload (includes .email) if valid, else null. */
async function verifyAccessJWT(token) {
  const parts = (token || '').split('.');
  if (parts.length !== 3) return null;
  const [headerB64, payloadB64, sigB64] = parts;
  let header, payload;
  try {
    header = b64urlToJson(headerB64);
    payload = b64urlToJson(payloadB64);
  } catch { return null; }

  if (!payload.exp || payload.exp * 1000 < Date.now()) return null;
  const aud = Array.isArray(payload.aud) ? payload.aud : [payload.aud];
  if (!aud.includes(ACCESS_AUD)) return null;
  if (payload.iss && payload.iss !== ACCESS_ISSUER) return null;

  try {
    const jwks = await getAccessJWKS();
    const jwk = jwks.find((k) => k.kid === header.kid);
    if (!jwk) return null;
    const key = await crypto.subtle.importKey(
      'jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']
    );
    const signingInput = new TextEncoder().encode(`${headerB64}.${payloadB64}`);
    const signature = b64urlToBytes(sigB64);
    const ok = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, signature, signingInput);
    if (!ok) return null;
  } catch { return null; }

  return payload;
}

/* Gate for admin endpoints. Returns null if OK, or an error Response.
   Two checks: a same-origin backstop against CSRF on state-changing
   requests, then the Cloudflare Access JWT. */
export async function requireAuth(request, env) {
  // CSRF backstop. Browsers always attach an Origin header to cross-origin
  // AND same-origin POST/PUT/DELETE/PATCH requests, so if one is present it
  // must match this deployment's own origin. A forged cross-site request
  // carries the attacker's Origin and is rejected before the JWT is even
  // checked. GET/HEAD are reads and exempt. Compared against the request's
  // own origin so this works on any deployment domain without hardcoding.
  const method = request.method.toUpperCase();
  if (method !== 'GET' && method !== 'HEAD') {
    const origin = request.headers.get('Origin');
    if (origin && origin !== new URL(request.url).origin) {
      return json({ error: 'Bad origin' }, 403);
    }
  }
  const token = getCookie(request, 'CF_Authorization');
  const payload = await verifyAccessJWT(token);
  return payload ? null : json({ error: 'Not authorised' }, 401);
}

/* Used by /api/me — same check, but returns the identity too. */
export async function getAccessIdentity(request) {
  const token = getCookie(request, 'CF_Authorization');
  return verifyAccessJWT(token);
}

/* ---------- text ---------- */
export function slugify(s) {
  return (s || '')
    .toLowerCase()
    .trim()
    .replace(/['"]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

export function escapeHtml(s) {
  return (s || '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* ---------- markdown ----------
   Small, dependency-free renderer. Input is escaped first, so no raw HTML
   from the DB is ever trusted. Covers headings, bold/italic, links, images,
   inline code, code fences, blockquotes, unordered/ordered lists, hr, paras. */
export function markdown(src) {
  if (!src) return '';
  let text = escapeHtml(src.replace(/\r\n/g, '\n'));

  // fenced code blocks -> placeholders so inline rules don't touch them
  const blocks = [];
  text = text.replace(/```([\s\S]*?)```/g, (_, code) => {
    blocks.push(`<pre><code>${code.replace(/^\n/, '')}</code></pre>`);
    return `\u0000${blocks.length - 1}\u0000`;
  });

  const lines = text.split('\n');
  const out = [];
  let para = [];
  let listType = null; // 'ul' | 'ol'

  const flushPara = () => {
    if (para.length) { out.push('<p>' + para.join(' ') + '</p>'); para = []; }
  };
  const closeList = () => { if (listType) { out.push(`</${listType}>`); listType = null; } };

  for (let raw of lines) {
    const line = raw.replace(/\s+$/, '');
    if (line === '') { flushPara(); closeList(); continue; }
    if (/^\u0000\d+\u0000$/.test(line)) { flushPara(); closeList(); out.push(line); continue; }

    let m;
    if ((m = line.match(/^(#{1,4})\s+(.*)$/))) {
      flushPara(); closeList();
      out.push(`<h${m[1].length}>${inline(m[2])}</h${m[1].length}>`);
    } else if (/^(-{3,}|\*{3,})$/.test(line)) {
      flushPara(); closeList(); out.push('<hr />');
    } else if ((m = line.match(/^&gt;\s?(.*)$/))) {
      flushPara(); closeList(); out.push(`<blockquote>${inline(m[1])}</blockquote>`);
    } else if ((m = line.match(/^[-*]\s+(.*)$/))) {
      flushPara();
      if (listType !== 'ul') { closeList(); out.push('<ul>'); listType = 'ul'; }
      out.push(`<li>${inline(m[1])}</li>`);
    } else if ((m = line.match(/^\d+\.\s+(.*)$/))) {
      flushPara();
      if (listType !== 'ol') { closeList(); out.push('<ol>'); listType = 'ol'; }
      out.push(`<li>${inline(m[1])}</li>`);
    } else {
      closeList(); para.push(inline(line));
    }
  }
  flushPara(); closeList();

  let html = out.join('\n');
  html = html.replace(/\u0000(\d+)\u0000/g, (_, i) => blocks[+i]);
  return html;
}

function inline(s) {
  return s
    .replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, (_, alt, url) => `<img src="${safeUrl(url)}" alt="${alt}" loading="lazy" />`)
    .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (_, txt, url) => `<a href="${safeUrl(url)}" target="_blank" rel="noopener">${txt}</a>`)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*])\*([^*]+)\*/g, '$1<em>$2</em>')
    .replace(/_([^_]+)_/g, '<em>$1</em>');
}

function safeUrl(u) {
  return /^(https?:|mailto:|\/|#)/i.test(u) ? u : '#';
}

const AUTO_NOTICE_DEFAULTS = {
  chat_auto_enabled: '1',
  chat_auto_minutes: '10',
  chat_auto_message:
    "Thanks for your message — I may be with a client right now, but I'll reply here or by email as soon as I'm free. " +
    "If you'd rather not wait, feel free to send an enquiry or book a discovery call time directly.",
};

/* If a visitor's latest message has sat unanswered for the configured
   wait time, drop in a one-off automated reply so they're not left
   wondering. Safe to call on every poll/load — it only fires once per
   silent gap, because the moment it inserts a message the "latest message"
   is no longer the visitor's, so the check is a no-op until they write
   again. Best-effort: never throws, never blocks the chat. */
export async function maybeSendAutoNotice(env, token) {
  try {
    const cfg = { ...AUTO_NOTICE_DEFAULTS };
    const { results: cfgRows } = await env.DB.prepare(
      "SELECT key, value FROM app_settings WHERE key LIKE 'chat_auto_%'"
    ).all();
    for (const r of cfgRows || []) if (r.key in cfg) cfg[r.key] = r.value;
    if (cfg.chat_auto_enabled === '0') return;
    const waitMinutes = parseInt(cfg.chat_auto_minutes, 10) || 10;

    const last = await env.DB.prepare(
      'SELECT id, sender, created_at FROM chat_messages WHERE thread_id=? ORDER BY id DESC LIMIT 1'
    ).bind(token).first();
    if (!last || last.sender !== 'visitor') return;

    const ageMs = Date.now() - new Date(String(last.created_at).replace(' ', 'T') + 'Z').getTime();
    if (ageMs < waitMinutes * 60 * 1000) return;

    // Re-check immediately before inserting to narrow (not fully close) the
    // race window between two near-simultaneous polls.
    const stillLast = await env.DB.prepare(
      'SELECT id FROM chat_messages WHERE thread_id=? ORDER BY id DESC LIMIT 1'
    ).bind(token).first();
    if (!stillLast || stillLast.id !== last.id) return;

    await env.DB.prepare(
      'INSERT INTO chat_messages (thread_id, sender, body, is_auto) VALUES (?, "admin", ?, 1)'
    ).bind(token, cfg.chat_auto_message).run();
    await env.DB.prepare("UPDATE chat_threads SET last_at=datetime('now') WHERE id=?").bind(token).run();
  } catch {
    // best-effort only — a failed check should never break the chat
  }
}

/* ---------- branded email shell ---------- */
const ORIGIN = 'https://ceibamethod.co.uk';
const LOGO_URL = 'https://raw.githubusercontent.com/9s4pr6gvvk-bot/ceiba/refs/heads/main/Ceiba%20not%20stacked%20png.png';

/* Wraps inner HTML in a CEIBA-branded, table-based email shell with a logo
   and an optional CTA button. Kept table-based + inline-styled for email
   client compatibility (no external stylesheet, no flex/grid). */
export function emailShell({ preheader = '', bodyHtml, buttonText, buttonUrl }) {
  const button = buttonUrl
    ? `<tr><td style="padding:8px 0 4px;">
         <a href="${buttonUrl}" target="_blank" style="display:inline-block; background-color:#1F4434 !important; color:#FBF9F3 !important; text-decoration:none; font-family:Arial,Helvetica,sans-serif; font-size:13px; letter-spacing:.08em; text-transform:uppercase; font-weight:600; padding:14px 30px; border-radius:3px; mso-padding-alt:0;">${escapeHtml(buttonText || 'Open in Admin')}</a>
       </td></tr>`
    : '';
  return `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light only">
<meta name="supported-color-schemes" content="light only">
<style>
  :root { color-scheme: light only; supported-color-schemes: light only; }
  body, table, td, div, p, a, span { -webkit-text-size-adjust: 100%; }
  /* Force light backgrounds/text regardless of the client's own dark-mode
     re-colouring (Gmail app, Outlook.com, some Apple Mail versions ignore
     the color-scheme meta tags above and invert inline styles anyway). */
  [data-ogsc] body, [data-ogsc] .cb-outer { background-color:#F4EFE3 !important; }
  [data-ogsc] .cb-card { background-color:#FBF9F3 !important; }
  [data-ogsc] .cb-text, [data-ogsc] .cb-text * { color:#232A24 !important; }
  [data-ogsc] .cb-muted, [data-ogsc] .cb-muted * { color:#5E665C !important; }
  [data-ogsc] .cb-footer, [data-ogsc] .cb-footer * { background-color:#16352A !important; color:rgba(255,255,255,.62) !important; }
  [data-ogsc] .cb-highlight { background-color:#F4EFE3 !important; color:#232A24 !important; }
  @media (prefers-color-scheme: dark) {
    .cb-outer { background-color:#F4EFE3 !important; }
    .cb-card { background-color:#FBF9F3 !important; }
    .cb-text, .cb-text * { color:#232A24 !important; }
    .cb-muted, .cb-muted * { color:#5E665C !important; }
    .cb-footer, .cb-footer * { background-color:#16352A !important; color:rgba(255,255,255,.62) !important; }
    .cb-highlight { background-color:#F4EFE3 !important; color:#232A24 !important; }
  }
</style>
</head>
<body style="margin:0; padding:0; background-color:#F4EFE3;">
  <div style="display:none; max-height:0; overflow:hidden; opacity:0;">${escapeHtml(preheader)}</div>
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="cb-outer" bgcolor="#F4EFE3" style="background-color:#F4EFE3; padding:32px 16px;">
    <tr><td align="center">
      <table role="presentation" width="100%" class="cb-card" bgcolor="#FBF9F3" style="max-width:520px; background-color:#FBF9F3; border-radius:6px; overflow:hidden; border:1px solid #D8CDB4;" cellpadding="0" cellspacing="0">
        <tr><td class="cb-card" bgcolor="#FBF9F3" style="background-color:#FBF9F3; padding:28px 32px; text-align:center; border-bottom:2px solid #C08A3E;">
          <img src="${LOGO_URL}" alt="CEIBA" style="height:38px; width:auto; display:inline-block;">
        </td></tr>
        <tr><td class="cb-card cb-text" bgcolor="#FBF9F3" style="background-color:#FBF9F3; padding:36px 32px 8px; font-family:Georgia,'Cormorant Garamond',serif; color:#232A24;">
          ${bodyHtml}
        </td></tr>
        <tr><td class="cb-card" bgcolor="#FBF9F3" style="background-color:#FBF9F3; padding:4px 32px 36px;">
          <table role="presentation" cellpadding="0" cellspacing="0">${button}</table>
        </td></tr>
        <tr><td class="cb-footer" bgcolor="#16352A" style="background-color:#16352A; padding:18px 32px; text-align:center; font-family:Arial,Helvetica,sans-serif; font-size:11px; letter-spacing:.05em; color:rgba(255,255,255,.62);">
          CEIBA &middot; ${ORIGIN.replace('https://', '')}
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

/* Fire a chat notification email via Resend, if configured. Non-blocking. */
export async function notifyChat(env, thread, body) {
  if (!env.RESEND_API_KEY || !env.NOTIFY_EMAIL) return;
  const from = env.NOTIFY_FROM || 'CEIBA chat <onboarding@resend.dev>';
  const who = thread.name ? `${thread.name}` : 'A website visitor';
  const adminUrl = `${ORIGIN}/admin#messages/${encodeURIComponent(thread.id ?? thread.token ?? '')}`;
  const html = emailShell({
    preheader: `${who} sent a new message on the CEIBA website.`,
    bodyHtml: `
      <p class="cb-text" style="font-size:19px; line-height:1.4; margin:0 0 18px; color:#232A24;"><strong>${escapeHtml(who)}</strong> sent a new message on the website.</p>
      <div class="cb-highlight" style="background-color:#F4EFE3; border-left:3px solid #C08A3E; padding:14px 18px; margin:0 0 18px; font-family:Arial,Helvetica,sans-serif; font-size:14px; line-height:1.6; color:#232A24;">
        ${escapeHtml(body).replace(/\n/g, '<br>')}
      </div>
      ${thread.email ? `<p class="cb-muted" style="font-family:Arial,Helvetica,sans-serif; font-size:13px; color:#5E665C; margin:0 0 18px;">Their email: ${escapeHtml(thread.email)}</p>` : ''}
      <p class="cb-muted" style="font-family:Arial,Helvetica,sans-serif; font-size:13px; color:#5E665C; margin:0;">Tap below to open the conversation and reply.</p>
    `,
    buttonText: 'Reply to message',
    buttonUrl: adminUrl,
  });
  try {
    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { authorization: `Bearer ${env.RESEND_API_KEY}`, 'content-type': 'application/json' },
      body: JSON.stringify({
        from,
        to: [env.NOTIFY_EMAIL],
        subject: `New CEIBA chat message from ${who}`,
        text: `${who} sent a message on the CEIBA website:\n\n"${body}"\n\nReply from your admin inbox: open your site and go to /admin → Messages.${thread.email ? `\n\nTheir email: ${thread.email}` : ''}`,
        html,
      }),
    });
  } catch { /* swallow — notification must never break the chat */ }
}

/* Fire a discovery-call enquiry email via Resend, if configured. Non-blocking. */
export async function notifySubmission(env, sub) {
  if (!env.RESEND_API_KEY || !env.NOTIFY_EMAIL) return;
  const from = env.NOTIFY_FROM || 'CEIBA website <onboarding@resend.dev>';
  const lines = [
    `New discovery call request from the CEIBA website:`,
    ``,
    `Name:    ${sub.name}`,
    `Email:   ${sub.email}`,
    sub.phone ? `Phone:   ${sub.phone}` : null,
    ``,
    sub.message ? `What's bringing them here:\n${sub.message}` : `(No message left.)`,
    ``,
    `You can reply straight to this email to reach them, or view it any time at /admin → Enquiries.`,
  ].filter(function (l) { return l !== null; });
  const adminUrl = `${ORIGIN}/admin#enquiries`;
  const html = emailShell({
    preheader: `${sub.name} requested a discovery call.`,
    bodyHtml: `
      <p class="cb-text" style="font-size:19px; line-height:1.4; margin:0 0 18px; color:#232A24;">New discovery call request from <strong>${escapeHtml(sub.name)}</strong>.</p>
      <table role="presentation" cellpadding="0" cellspacing="0" class="cb-text" style="font-family:Arial,Helvetica,sans-serif; font-size:14px; color:#232A24; margin:0 0 18px;">
        <tr><td class="cb-muted" style="padding:3px 10px 3px 0; color:#8E948A;">Email</td><td class="cb-text" style="padding:3px 0; color:#232A24;">${escapeHtml(sub.email)}</td></tr>
        ${sub.phone ? `<tr><td class="cb-muted" style="padding:3px 10px 3px 0; color:#8E948A;">Phone</td><td class="cb-text" style="padding:3px 0; color:#232A24;">${escapeHtml(sub.phone)}</td></tr>` : ''}
      </table>
      ${sub.message ? `<div class="cb-highlight" style="background-color:#F4EFE3; border-left:3px solid #C08A3E; padding:14px 18px; margin:0 0 18px; font-family:Arial,Helvetica,sans-serif; font-size:14px; line-height:1.6; color:#232A24;">${escapeHtml(sub.message).replace(/\n/g, '<br>')}</div>` : ''}
      <p class="cb-muted" style="font-family:Arial,Helvetica,sans-serif; font-size:13px; color:#5E665C; margin:0;">Reply straight to this email to reach them, or open it in the admin.</p>
    `,
    buttonText: 'View in Admin',
    buttonUrl: adminUrl,
  });
  try {
    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { authorization: `Bearer ${env.RESEND_API_KEY}`, 'content-type': 'application/json' },
      body: JSON.stringify({
        from,
        to: [env.NOTIFY_EMAIL],
        reply_to: sub.email,
        subject: `New discovery call request from ${sub.name}`,
        text: lines.join('\n'),
        html,
      }),
    });
  } catch { /* swallow — notification must never break the enquiry capture */ }
}

/* Renders a client-editable plain-text email template (with {{name}}/{{when}}
   tokens) into both a plain-text body and an HTML paragraph block. Token
   substitution for the HTML version uses safe placeholder markers rather
   than regex-matching the raw name/date text, so special characters in
   either can't break the output. */
export function renderEmailTemplate(rawBody, vars) {
  const plainText = rawBody
    .replace(/\{\{\s*name\s*\}\}/g, vars.name)
    .replace(/\{\{\s*when\s*\}\}/g, vars.when);

  const NAME_MARK = '\u0000N\u0000', WHEN_MARK = '\u0000W\u0000';
  const marked = rawBody
    .replace(/\{\{\s*name\s*\}\}/g, NAME_MARK)
    .replace(/\{\{\s*when\s*\}\}/g, WHEN_MARK);
  const bodyHtml = marked
    .split(/\n\s*\n/)
    .map((para) => {
      let esc = escapeHtml(para).replace(/\n/g, '<br>');
      esc = esc.split(NAME_MARK).join(`<strong>${escapeHtml(vars.name)}</strong>`);
      esc = esc.split(WHEN_MARK).join(`<strong>${escapeHtml(vars.when)}</strong>`);
      return `<p class="cb-text" style="font-family:Arial,Helvetica,sans-serif; font-size:14px; line-height:1.6; color:#232A24; margin:0 0 16px;">${esc}</p>`;
    })
    .join('');
  return { plainText, bodyHtml };
}

/* Reads the client-editable email templates from app_settings. */
export async function getEmailTemplates(env) {
  const defaults = {
    email_requested_subject: "We've received your consultation request — CEIBA",
    email_requested_body: "Hi {{name}},\n\nThanks for requesting a consultation. Here's what you asked for:\n\n{{when}}\n\nWe'll confirm by email shortly. If that time turns out not to work, we'll be in touch to find another.\n\nWarm regards,\nCEIBA",
    email_confirm_subject: 'Your consultation is confirmed — CEIBA',
    email_confirm_body: "Hi {{name}},\n\nGood news, your consultation is confirmed for:\n\n{{when}}\n\nWe look forward to speaking with you. If you need to rearrange, just reply to this email.\n\nWarm regards,\nCEIBA",
    email_decline_subject: 'About your consultation request — CEIBA',
    email_decline_body: "Hi {{name}},\n\nThank you for asking about {{when}}. I'm sorry, that time isn't available.\n\nI'd be glad to find another that works for you. Would any of these suit?\n\n[ add a couple of times here ]\n\nIf none of those are right, just reply to this email or book another slot on our website and we'll be glad to help.\n\nWarm regards,\nCEIBA",
  };
  const out = { ...defaults };
  try {
    const { results } = await env.DB.prepare(
      "SELECT key, value FROM app_settings WHERE key LIKE 'email_%'"
    ).all();
    for (const r of results || []) out[r.key] = r.value;
  } catch { /* table may not exist yet; defaults are fine */ }
  return out;
}

/* Notify admin + acknowledge visitor for a new booking request. */
export async function notifyBooking(env, booking, whenLabel) {
  const from = env.NOTIFY_FROM || 'CEIBA website <onboarding@resend.dev>';
  // Admin notification.
  if (env.RESEND_API_KEY && env.NOTIFY_EMAIL) {
    const lines = [
      `New consultation request from the CEIBA website:`,
      ``,
      `Name:     ${booking.name}`,
      `Email:    ${booking.email}`,
      booking.phone ? `Phone:    ${booking.phone}` : null,
      booking.service ? `Service:  ${booking.service}` : null,
      `Slot:     ${whenLabel}`,
      `Duration: ${booking.duration_min} min`,
      ``,
      booking.note ? `Note:\n${booking.note}` : `(No note left.)`,
      ``,
      `Open /admin → Bookings to accept or decline.`,
    ].filter(function (l) { return l !== null; });
    const adminUrl = `${ORIGIN}/admin#bookings`;
    const html = emailShell({
      preheader: `${booking.name} requested a consultation for ${whenLabel}.`,
      bodyHtml: `
        <p class="cb-text" style="font-size:19px; line-height:1.4; margin:0 0 18px; color:#232A24;">New consultation request from <strong>${escapeHtml(booking.name)}</strong>.</p>
        <table role="presentation" cellpadding="0" cellspacing="0" class="cb-text" style="font-family:Arial,Helvetica,sans-serif; font-size:14px; color:#232A24; margin:0 0 18px;">
          <tr><td class="cb-muted" style="padding:3px 10px 3px 0; color:#8E948A;">Email</td><td class="cb-text" style="padding:3px 0; color:#232A24;">${escapeHtml(booking.email)}</td></tr>
          ${booking.phone ? `<tr><td class="cb-muted" style="padding:3px 10px 3px 0; color:#8E948A;">Phone</td><td class="cb-text" style="padding:3px 0; color:#232A24;">${escapeHtml(booking.phone)}</td></tr>` : ''}
          ${booking.service ? `<tr><td class="cb-muted" style="padding:3px 10px 3px 0; color:#8E948A;">Service</td><td class="cb-text" style="padding:3px 0; color:#232A24;">${escapeHtml(booking.service)}</td></tr>` : ''}
          <tr><td class="cb-muted" style="padding:3px 10px 3px 0; color:#8E948A;">Slot</td><td class="cb-text" style="padding:3px 0; color:#232A24;">${escapeHtml(whenLabel)}</td></tr>
          <tr><td class="cb-muted" style="padding:3px 10px 3px 0; color:#8E948A;">Duration</td><td class="cb-text" style="padding:3px 0; color:#232A24;">${escapeHtml(String(booking.duration_min))} min</td></tr>
        </table>
        ${booking.note ? `<div class="cb-highlight" style="background-color:#F4EFE3; border-left:3px solid #C08A3E; padding:14px 18px; margin:0 0 18px; font-family:Arial,Helvetica,sans-serif; font-size:14px; line-height:1.6; color:#232A24;">${escapeHtml(booking.note).replace(/\n/g, '<br>')}</div>` : ''}
        <p class="cb-muted" style="font-family:Arial,Helvetica,sans-serif; font-size:13px; color:#5E665C; margin:0;">Accept or decline from the admin.</p>
      `,
      buttonText: 'Open in Admin',
      buttonUrl: adminUrl,
    });
    try {
      await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { authorization: `Bearer ${env.RESEND_API_KEY}`, 'content-type': 'application/json' },
        body: JSON.stringify({
          from,
          to: [env.NOTIFY_EMAIL],
          reply_to: booking.email,
          subject: `New booking request from ${booking.name} — ${whenLabel}`,
          text: lines.join('\n'),
          html,
        }),
      });
    } catch { /* swallow */ }
  }
  // Visitor acknowledgement.
  if (env.RESEND_API_KEY) {
    const tpl = await getEmailTemplates(env);
    // The sign-off is part of the template now, so nothing is appended here.
    const { plainText, bodyHtml } = renderEmailTemplate(tpl.email_requested_body, { name: booking.name, when: whenLabel });
    const ack = plainText.split('\n');
    const subject = tpl.email_requested_subject
      .replace(/\{\{\s*name\s*\}\}/g, booking.name)
      .replace(/\{\{\s*when\s*\}\}/g, whenLabel);
    const html = emailShell({
      preheader: `We've received your consultation request for ${whenLabel}.`,
      bodyHtml,
    });
    try {
      await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { authorization: `Bearer ${env.RESEND_API_KEY}`, 'content-type': 'application/json' },
        body: JSON.stringify({
          from,
          to: [booking.email],
          reply_to: env.NOTIFY_EMAIL || undefined,
          subject,
          text: ack.join('\n'),
          html,
        }),
      });
    } catch { /* swallow */ }
  }
}
