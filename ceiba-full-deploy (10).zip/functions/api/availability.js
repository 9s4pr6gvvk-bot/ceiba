import { json } from '../_shared.js';
import { getSettings, computeAvailability } from '../_availability.js';

// GET /api/availability -> public: open slots grouped by day, plus meta.
export async function onRequestGet({ env }) {
  const settings = await getSettings(env);
  const days = await computeAvailability(env, settings);
  return json({ duration: settings.duration, timezone: settings.timezone, days });
}
