import { json, bad, requireAuth, notifyBooking, verifyTurnstile, rateLimited, tooManyRequests, clientIp } from '../_shared.js';
import { getSettings, isSlotBookable, formatSlot, ensureBookingTables } from '../_availability.js';

// GET /api/bookings -> admin: all bookings (pending first, then by slot).
export async function onRequestGet({ request, env }) {
  const unauth = await requireAuth(request, env);
  if (unauth) return unauth;
  await ensureBookingTables(env);
  const { results } = await env.DB.prepare(
    "SELECT * FROM bookings ORDER BY (status='pending') DESC, slot_start ASC"
  ).all();
  return json(results || []);
}

// POST /api/bookings -> public: visitor claims an available slot.
export async function onRequestPost({ request, env, waitUntil }) {
  if (await rateLimited(env, `bookings:${clientIp(request)}`, 5, 600)) return tooManyRequests();

  let b = {};
  const ct = request.headers.get('content-type') || '';
  try {
    if (ct.includes('application/json')) {
      b = await request.json();
    } else {
      const form = await request.formData();
      form.forEach(function (v, k) { b[k] = v; });
    }
  } catch { return bad('Could not read your request.', 400); }

  const turnOk = await verifyTurnstile(request, env, b.turnstileToken);
  if (!turnOk) return bad('Verification failed. Please try again.', 403);

  const name = (b.name || '').toString().trim().slice(0, 120);
  const email = (b.email || '').toString().trim().slice(0, 200);
  const slot = (b.slot_start || '').toString().trim().slice(0, 40);

  if (!name) return bad('Please enter your name.', 422);
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return bad('Please enter a valid email address.', 422);
  if (!slot) return bad('Please choose a time.', 422);

  const settings = await getSettings(env);

  // Re-validate server-side so nobody books outside availability or grabs a taken slot.
  const ok = await isSlotBookable(env, slot, settings);
  if (!ok) return bad('Sorry, that time is no longer available. Please pick another.', 409);

  const phone = (b.phone || '').toString().trim().slice(0, 60);
  const service = (b.service || '').toString().trim().slice(0, 160);
  const note = (b.note || '').toString().trim().slice(0, 2000);
  const token = crypto.randomUUID();

  let booking;
  try {
    await ensureBookingTables(env);
    const res = await env.DB.prepare(
      `INSERT INTO bookings (token, name, email, phone, service, slot_start, duration_min, note)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?) RETURNING *`
    ).bind(token, name, email, phone, service, slot, settings.duration, note).all();
    booking = res.results[0];
  } catch (e) {
    // Log the real reason for us; don't leak DB internals to an anonymous caller.
    console.error('booking insert failed:', e && e.message ? e.message : e);
    return bad('Sorry, we couldn\u2019t save your request just now. Please try again.', 500);
  }

  const when = formatSlot(slot, settings.timezone);
  // Fires two Resend calls (admin notice + visitor acknowledgement) — via
  // waitUntil so neither delays the booking confirmation response.
  waitUntil(notifyBooking(env, booking, when));
  return json({ ok: true, token: booking.token, when });
}
