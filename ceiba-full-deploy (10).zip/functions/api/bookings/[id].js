import { json, bad, requireAuth, emailShell, getEmailTemplates, renderEmailTemplate } from '../../_shared.js';
import { getSettings, formatSlot } from '../../_availability.js';

// GET    /api/bookings/:id -> admin views one (marks seen)
// PUT    /api/bookings/:id -> admin acts: { action: accept|decline, admin_note? }
// DELETE /api/bookings/:id -> admin removes
export async function onRequestGet({ request, env, params }) {
  const unauth = await requireAuth(request, env);
  if (unauth) return unauth;
  const row = await env.DB.prepare('SELECT * FROM bookings WHERE id=?').bind(params.id).first();
  if (!row) return bad('Not found', 404);

  // Preview the exact email that Accept/Decline would send, so the admin can
  // read and edit it before anything goes out. Does not change the booking.
  const preview = new URL(request.url).searchParams.get('preview');
  if (preview === 'accept' || preview === 'decline') {
    const status = preview === 'accept' ? 'accepted' : 'declined';
    const settings = await getSettings(env);
    const when = formatSlot(row.slot_start, settings.timezone);
    return json(composeDecisionEmail(await getEmailTemplates(env), row, status, when));
  }

  if (!row.seen_by_admin) {
    await env.DB.prepare('UPDATE bookings SET seen_by_admin=1 WHERE id=?').bind(row.id).run();
    row.seen_by_admin = 1;
  }
  return json(row);
}

// Builds the subject and the full plain-text body (including sign-off) exactly
// as the decision email would read. Used for the preview and as the fallback
// when the admin sends without editing.
function composeDecisionEmail(tpl, booking, status, when) {
  const subjectKey = status === 'accepted' ? 'email_confirm_subject' : 'email_decline_subject';
  const bodyKey = status === 'accepted' ? 'email_confirm_body' : 'email_decline_body';
  const subject = tpl[subjectKey]
    .replace(/\{\{\s*name\s*\}\}/g, booking.name)
    .replace(/\{\{\s*when\s*\}\}/g, when);
  // The sign-off now lives in the template itself, so the body is the
  // template verbatim. Nothing is appended here.
  const { plainText } = renderEmailTemplate(tpl[bodyKey], { name: booking.name, when });
  return { subject, body: plainText };
}

export async function onRequestPut({ request, env, params }) {
  const unauth = await requireAuth(request, env);
  if (unauth) return unauth;
  let b;
  try { b = await request.json(); } catch { return bad('Bad request', 400); }

  const booking = await env.DB.prepare('SELECT * FROM bookings WHERE id=?').bind(params.id).first();
  if (!booking) return bad('Not found', 404);

  const action = (b.action || '').toString();
  const adminNote = (b.admin_note || '').toString().trim().slice(0, 2000);
  // The admin can edit the email in a card before sending; when she does, these
  // hold the final subject/body and are sent verbatim.
  const customSubject = typeof b.subject === 'string' ? b.subject.trim().slice(0, 200) : '';
  const customBody = typeof b.body === 'string' ? b.body.slice(0, 5000) : '';

  let status;
  if (action === 'accept') status = 'accepted';
  else if (action === 'decline') status = 'declined';
  else return bad('Unknown action.', 400);

  const { results } = await env.DB.prepare(
    `UPDATE bookings SET status=?, admin_note=?, updated_at=datetime('now') WHERE id=? RETURNING *`
  ).bind(status, adminNote, booking.id).all();
  const updated = results[0];

  const settings = await getSettings(env);
  const when = formatSlot(booking.slot_start, settings.timezone);
  await emailDecision(env, booking, status, when, adminNote, { subject: customSubject, body: customBody });

  return json(updated);
}

export async function onRequestDelete({ request, env, params }) {
  const unauth = await requireAuth(request, env);
  if (unauth) return unauth;
  await env.DB.prepare('DELETE FROM bookings WHERE id=?').bind(params.id).run();
  return json({ ok: true });
}

async function emailDecision(env, booking, status, when, adminNote, custom) {
  if (!env.RESEND_API_KEY) return;
  const from = env.NOTIFY_FROM || 'CEIBA website <onboarding@resend.dev>';

  const tpl = await getEmailTemplates(env);
  const composed = composeDecisionEmail(tpl, booking, status, when);

  // The template (and the card) carry the full email including the sign-off,
  // so we send the text verbatim and never append anything.
  let subject, text;
  if (custom && custom.body && custom.body.trim()) {
    subject = (custom.subject && custom.subject.trim()) || composed.subject;
    text = custom.body;
  } else {
    subject = composed.subject;
    text = adminNote ? `${composed.body}\n\n${adminNote}` : composed.body;
  }
  const bodyHtml = renderEmailTemplate(text, { name: booking.name, when }).bodyHtml;

  const html = emailShell({
    preheader: status === 'accepted' ? `Your consultation is confirmed for ${when}.` : `An update on your request for ${when}.`,
    bodyHtml,
  });

  try {
    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { authorization: `Bearer ${env.RESEND_API_KEY}`, 'content-type': 'application/json' },
      body: JSON.stringify({
        from,
        to: [booking.email],
        reply_to: env.NOTIFY_EMAIL || undefined,
        subject,
        text,
        html,
      }),
    });
  } catch { /* swallow */ }
}

// Small local escaper for the admin_note block (avoids importing the full
// escapeHtml just for this one call site -- same behaviour).
function escapeHtmlLite(s) {
  return String(s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;')
    .replace(/\n/g, '<br>');
}
