import { json } from '../_shared.js';

// Public read-only endpoint. Returns the current chat widget wording set in
// the admin console's Chat widget settings card, so the live site can
// render it. No auth — this is only ever the same copy shown on the page.
const DEFAULTS = {
  chat_launcher_text: 'Chat with us',
  chat_subtitle: 'We usually reply within a few hours',
  chat_intro: "Hello — thanks for stopping by. Leave a message and I'll get back to you personally. If it's outside working hours I'll reply as soon as I can.",
  chat_auto_cta: 'Send a message or book a call',
};

export async function onRequestGet({ env }) {
  const out = { ...DEFAULTS };
  try {
    const { results } = await env.DB.prepare(
      "SELECT key, value FROM app_settings WHERE key LIKE 'chat_%'"
    ).all();
    for (const r of results || []) if (r.key in out) out[r.key] = r.value;
  } catch {
    // table may not exist yet on a fresh deploy; defaults are fine
  }
  return json(out);
}
