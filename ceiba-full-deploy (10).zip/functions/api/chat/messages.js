import { json, bad, requireAuth } from '../../_shared.js';

export async function onRequestGet({ request, env }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  const url = new URL(request.url);
  const token = (url.searchParams.get('token') || '').trim();
  if (!token) return bad('token required');
  const thread = await env.DB.prepare('SELECT id,name,email FROM chat_threads WHERE id=?').bind(token).first();
  if (!thread) return json({ error: 'Not found' }, 404);
  const { results } = await env.DB.prepare(
    'SELECT id, sender, body, is_auto, created_at FROM chat_messages WHERE thread_id=? ORDER BY id ASC'
  ).bind(token).all();
  await env.DB.prepare('UPDATE chat_threads SET admin_unread=0 WHERE id=?').bind(token).run();
  return json({ thread, messages: results || [] });
}

export async function onRequestPost({ request, env }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  let b; try { b = await request.json(); } catch { return bad('Bad request'); }
  const token = (b.token || '').trim();
  const body = (b.body || '').trim();
  if (!token || !body) return bad('Message and thread are required');
  const thread = await env.DB.prepare('SELECT id FROM chat_threads WHERE id=?').bind(token).first();
  if (!thread) return bad('Unknown thread', 404);

  const { meta } = await env.DB.prepare(
    'INSERT INTO chat_messages (thread_id, sender, body) VALUES (?, "admin", ?)'
  ).bind(token, body).run();
  await env.DB.prepare(
    "UPDATE chat_threads SET visitor_unread=visitor_unread+1, admin_unread=0, last_at=datetime('now') WHERE id=?"
  ).bind(token).run();
  return json({ id: meta.last_row_id });
}
