import { json, maybeSendAutoNotice } from '../../_shared.js';

async function poll(env, token, after) {
  token = (token || '').trim();
  after = parseInt(after || '0', 10) || 0;
  if (!token) return json({ messages: [] });

  await maybeSendAutoNotice(env, token);

  const { results } = await env.DB.prepare(
    'SELECT id, sender, body, is_auto, created_at FROM chat_messages WHERE thread_id=? AND id>? ORDER BY id ASC'
  ).bind(token, after).all();

  if (results && results.length) {
    await env.DB.prepare('UPDATE chat_threads SET visitor_unread=0 WHERE id=?').bind(token).run();
  }
  return json({ messages: results || [] });
}

// Preferred: token in the POST body, so the session credential never lands in
// a URL (and therefore never in access logs, browser history, or a Referer).
export async function onRequestPost({ request, env }) {
  let b; try { b = await request.json(); } catch { b = {}; }
  return poll(env, b.token, b.after);
}

// Kept for backward compatibility with any client still polling via GET during
// a deploy. New clients use POST above.
export async function onRequestGet({ request, env }) {
  const url = new URL(request.url);
  return poll(env, url.searchParams.get('token'), url.searchParams.get('after'));
}
