import { json, bad, notifyChat, rateLimited, tooManyRequests, clientIp } from '../../_shared.js';

export async function onRequestPost({ request, env, waitUntil }) {
  if (await rateLimited(env, `chat-send:${clientIp(request)}`, 20, 300)) return tooManyRequests();

  let b; try { b = await request.json(); } catch { return bad('Bad request'); }
  const token = (b.token || '').trim();
  const body = (b.body || '').trim();
  if (!token || !body) return bad('Message and session are required');
  if (body.length > 4000) return bad('Message too long');

  const thread = await env.DB.prepare('SELECT * FROM chat_threads WHERE id=?').bind(token).first();
  if (!thread) return bad('Unknown session', 404);

  const { meta } = await env.DB.prepare(
    'INSERT INTO chat_messages (thread_id, sender, body) VALUES (?, "visitor", ?)'
  ).bind(token, body).run();
  await env.DB.prepare(
    "UPDATE chat_threads SET admin_unread=admin_unread+1, last_at=datetime('now') WHERE id=?"
  ).bind(token).run();

  // phone/email notification to the owner (no-op unless Resend is configured).
  // Fired via waitUntil so the Resend network call never delays this response —
  // an awaited call here was racing against the visitor's own background poll,
  // which could render the just-sent message a second time before this
  // response got back to the client.
  waitUntil(notifyChat(env, thread, body));

  return json({ id: meta.last_row_id });
}
