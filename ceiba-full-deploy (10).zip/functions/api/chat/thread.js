import { json, bad, maybeSendAutoNotice, verifyTurnstile, rateLimited, tooManyRequests, clientIp } from '../../_shared.js';

export async function onRequestPost({ request, env }) {
  let b; try { b = await request.json(); } catch { b = {}; }
  let token = (b.token || '').trim();

  // The anonymous stub-creation on page load (no name/email yet) and
  // resuming an existing conversation aren't gated — only the prechat
  // "start conversation" submission carries a name, so that's the one
  // human-initiated action worth verifying and rate limiting.
  if (b.name) {
    if (await rateLimited(env, `chat-thread:${clientIp(request)}`, 10, 600)) return tooManyRequests();
    const ok = await verifyTurnstile(request, env, b.turnstileToken);
    if (!ok) return bad('Verification failed. Please try again.', 403);
  }

  let thread = token ? await env.DB.prepare('SELECT * FROM chat_threads WHERE id=?').bind(token).first() : null;

  if (!thread) {
    // Creating a brand-new thread row. This path is otherwise unauthenticated
    // and hit on every fresh page load (anonymous stub, no name yet), so cap
    // it per IP or a script could spam INSERTs and bloat the table. Generous
    // enough for real visitors (new tab, cleared storage), brutal for a loop.
    if (await rateLimited(env, `chat-thread-new:${clientIp(request)}`, 20, 600)) return tooManyRequests();
    token = crypto.randomUUID();
    await env.DB.prepare('INSERT INTO chat_threads (id, name, email) VALUES (?,?,?)')
      .bind(token, b.name || null, b.email || null).run();
    thread = { id: token, name: b.name || null, email: b.email || null };
  } else if ((b.name && !thread.name) || (b.email && !thread.email)) {
    await env.DB.prepare('UPDATE chat_threads SET name=COALESCE(name,?), email=COALESCE(email,?) WHERE id=?')
      .bind(b.name || null, b.email || null, token).run();
  }

  await maybeSendAutoNotice(env, token);

  const { results } = await env.DB.prepare(
    'SELECT id, sender, body, is_auto, created_at FROM chat_messages WHERE thread_id=? ORDER BY id ASC'
  ).bind(token).all();

  // resuming clears the visitor's unread flag
  await env.DB.prepare('UPDATE chat_threads SET visitor_unread=0 WHERE id=?').bind(token).run();
  return json({ token, name: thread.name, email: thread.email, messages: results || [] });
}
