import { json, requireAuth } from '../../_shared.js';

export async function onRequestGet({ request, env }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  const { results } = await env.DB.prepare(`
    SELECT t.id, t.name, t.email, t.last_at, t.admin_unread,
           (SELECT body   FROM chat_messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1) AS last_body,
           (SELECT sender FROM chat_messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1) AS last_sender
    FROM chat_threads t
    WHERE EXISTS (SELECT 1 FROM chat_messages m WHERE m.thread_id=t.id)
    ORDER BY t.last_at DESC
  `).all();
  const total = (results || []).reduce((n, r) => n + (r.admin_unread || 0), 0);
  return json({ total_unread: total, threads: results || [] });
}
