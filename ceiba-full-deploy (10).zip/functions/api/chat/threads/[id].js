import { json, bad, requireAuth } from '../../../_shared.js';

// DELETE /api/chat/threads/:id -> admin removes a whole conversation.
export async function onRequestDelete({ request, env, params }) {
  const gate = await requireAuth(request, env);
  if (gate) return gate;
  const id = params.id;
  if (!id) return bad('Missing thread id', 400);
  try {
    await env.DB.prepare('DELETE FROM chat_messages WHERE thread_id=?').bind(id).run();
    await env.DB.prepare('DELETE FROM chat_threads WHERE id=?').bind(id).run();
  } catch (e) {
    return bad('Could not delete conversation: ' + (e && e.message ? e.message : 'unknown'), 500);
  }
  return json({ ok: true });
}
