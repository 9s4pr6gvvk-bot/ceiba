import { json, getAccessIdentity } from '../_shared.js';

export async function onRequestGet({ request }) {
  const identity = await getAccessIdentity(request);
  return json({ authed: !!identity, email: identity ? identity.email : null });
}
