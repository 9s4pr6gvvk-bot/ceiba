import { json, bad, requireAuth, slugify } from '../_shared.js';

// GET /api/posts        -> published list (public)
// GET /api/posts?all=1  -> every post incl. drafts (admin only)
export async function onRequestGet({ request, env }) {
  const url = new URL(request.url);
  const wantAll = url.searchParams.get('all') === '1';
  const admin = !(await requireAuth(request, env));
  if (wantAll && !admin) return json({ error: 'Not authorised' }, 401);

  const sql = wantAll
    ? 'SELECT id, slug, title, excerpt, cover, published, created_at, updated_at, published_at FROM posts ORDER BY COALESCE(published_at, created_at) DESC'
    : 'SELECT id, slug, title, excerpt, cover, author, published_at FROM posts WHERE published = 1 ORDER BY published_at DESC';
  const { results } = await env.DB.prepare(sql).all();
  return json(results || []);
}

// POST /api/posts  (admin) create
export async function onRequestPost({ request, env }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  let b; try { b = await request.json(); } catch { return bad('Bad request'); }
  if (!b.title || !b.title.trim()) return bad('Title is required');
  if (!b.body || !b.body.trim()) return bad('Body is required');

  let slug = slugify(b.slug || b.title);
  if (!slug) slug = 'post-' + Date.now();
  // ensure unique
  const clash = await env.DB.prepare('SELECT id FROM posts WHERE slug=?').bind(slug).first();
  if (clash) slug = slug + '-' + Date.now().toString(36).slice(-4);

  const pub = b.published ? 1 : 0;
  const now = new Date().toISOString();
  const { meta } = await env.DB.prepare(
    `INSERT INTO posts (slug,title,excerpt,body,cover,meta_description,author,published,published_at)
     VALUES (?,?,?,?,?,?,?,?,?)`
  ).bind(
    slug, b.title.trim(), b.excerpt || null, b.body, b.cover || null,
    b.meta_description || null, b.author || 'CEIBA', pub, pub ? now : null
  ).run();
  return json({ id: meta.last_row_id, slug }, 201);
}
