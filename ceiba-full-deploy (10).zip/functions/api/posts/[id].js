import { json, bad, requireAuth, slugify } from '../../_shared.js';

// GET one full post by id (admin editor)
export async function onRequestGet({ request, env, params }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  const row = await env.DB.prepare('SELECT * FROM posts WHERE id=?').bind(params.id).first();
  if (!row) return json({ error: 'Not found' }, 404);
  return json(row);
}

export async function onRequestPut({ request, env, params }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  let b; try { b = await request.json(); } catch { return bad('Bad request'); }
  if (!b.title || !b.title.trim()) return bad('Title is required');
  if (!b.body || !b.body.trim()) return bad('Body is required');

  const existing = await env.DB.prepare('SELECT slug, published, published_at FROM posts WHERE id=?').bind(params.id).first();
  if (!existing) return json({ error: 'Not found' }, 404);

  // keep the existing slug unless the editor explicitly changed it
  let slug = existing.slug;
  if (b.slug && slugify(b.slug) !== existing.slug) {
    slug = slugify(b.slug) || existing.slug;
    const clash = await env.DB.prepare('SELECT id FROM posts WHERE slug=? AND id<>?').bind(slug, params.id).first();
    if (clash) return bad('That URL slug is already used by another post');
  }

  const pub = b.published ? 1 : 0;
  // set published_at the first time it goes live; keep it thereafter
  let publishedAt = existing.published_at;
  if (pub && !existing.published) publishedAt = new Date().toISOString();
  if (!pub) publishedAt = existing.published_at; // leave history intact

  await env.DB.prepare(
    `UPDATE posts SET slug=?, title=?, excerpt=?, body=?, cover=?, meta_description=?, author=?,
      published=?, published_at=?, updated_at=datetime('now') WHERE id=?`
  ).bind(
    slug, b.title.trim(), b.excerpt || null, b.body, b.cover || null,
    b.meta_description || null, b.author || 'CEIBA', pub, publishedAt, params.id
  ).run();
  return json({ ok: true, slug });
}

export async function onRequestDelete({ request, env, params }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  await env.DB.prepare('DELETE FROM posts WHERE id=?').bind(params.id).run();
  return json({ ok: true });
}
