import { json } from '../_shared.js';

// Public read-only endpoint. Returns the current prices set in the admin
// console's Pricing tab so the live site can render them. No auth — this
// mirrors what is already shown on the pages, just kept in one place.
const DEFAULTS = {
  price_individual: '95',
  price_programme: '900',
  price_group: '900',
  price_group_was: '1200',
};

export async function onRequestGet({ env }) {
  const out = { ...DEFAULTS };
  try {
    const { results } = await env.DB.prepare(
      "SELECT key, value FROM app_settings WHERE key LIKE 'price_%'"
    ).all();
    for (const r of results || []) out[r.key] = r.value;
  } catch {
    // table may not exist yet on a fresh deploy; defaults are fine
  }
  return json(out);
}
