import { json, bad, requireAuth } from '../_shared.js';
import { ensureBookingTables } from '../_availability.js';

// Booking availability settings (keys are booking_* in app_settings).
// GET /api/settings -> admin reads current values (defaults filled in)
// PUT /api/settings -> admin saves { booking_days, booking_start, ... }
const KEYS = [
  'booking_days', 'booking_start', 'booking_end', 'booking_duration',
  'booking_buffer', 'booking_lead_hours', 'booking_horizon', 'booking_timezone',
  'price_individual', 'price_programme', 'price_group', 'price_group_was',
  'chat_launcher_text', 'chat_subtitle', 'chat_intro',
  'chat_auto_enabled', 'chat_auto_minutes', 'chat_auto_cta', 'chat_auto_message',
  'chat_quick_replies',
  'email_requested_subject', 'email_requested_body',
  'email_confirm_subject', 'email_confirm_body',
  'email_decline_subject', 'email_decline_body',
];
const DEFAULTS = {
  booking_days: '1,2,3,4,5',
  booking_start: '09:00',
  booking_end: '17:00',
  booking_duration: '30',
  booking_buffer: '0',
  booking_lead_hours: '24',
  booking_horizon: '21',
  booking_timezone: 'Europe/London',
  price_individual: '95',
  price_programme: '900',
  price_group: '900',
  price_group_was: '1200',
  chat_launcher_text: 'Chat with us',
  chat_subtitle: 'We usually reply within a few hours',
  chat_intro: "Hello — thanks for stopping by. Leave a message and I'll get back to you personally. If it's outside working hours I'll reply as soon as I can.",
  chat_auto_enabled: '1',
  chat_auto_minutes: '10',
  chat_auto_cta: 'Send a message or book a call',
  chat_auto_message: "Thanks for your message — I may be with a client right now, but I'll reply here or by email as soon as I'm free. If you'd rather not wait, feel free to send an enquiry or book a discovery call time directly.",
  chat_quick_replies: JSON.stringify([
    { label: 'Thanks, tell me more', text: "Hi {{name}},\n\nThank you for getting in touch. I'd be glad to help. Could you tell me a little more about what's prompting you to reach out, and I'll suggest a couple of times for a call?\n\nWarm wishes,\nGerry" },
    { label: 'Suggest a discovery call', text: "Hi {{name}},\n\nThe easiest next step is usually a short discovery call, no pressure at all, just a chance to talk things through. You can pick a time that suits you here: https://ceibamethod.co.uk/#contact\n\nWarm wishes,\nGerry" },
    { label: 'Follow up after their reply', text: "Hi {{name}},\n\nThank you, that gives me a good sense of where you are. Shall we set up a call to go a little deeper?\n\nWarm wishes,\nGerry" },
  ]),
  email_requested_subject: "We've received your consultation request — CEIBA",
  email_requested_body: "Hi {{name}},\n\nThanks for requesting a consultation. Here's what you asked for:\n\n{{when}}\n\nWe'll confirm by email shortly. If that time turns out not to work, we'll be in touch to find another.\n\nWarm regards,\nCEIBA",
  email_confirm_subject: 'Your consultation is confirmed — CEIBA',
  email_confirm_body: "Hi {{name}},\n\nGood news, your consultation is confirmed for:\n\n{{when}}\n\nWe look forward to speaking with you. If you need to rearrange, just reply to this email.\n\nWarm regards,\nCEIBA",
  email_decline_subject: 'About your consultation request — CEIBA',
  email_decline_body: "Hi {{name}},\n\nThank you for asking about {{when}}. I'm sorry, that time isn't available.\n\nI'd be glad to find another that works for you. Would any of these suit?\n\n[ add a couple of times here ]\n\nIf none of those are right, just reply to this email or book another slot on our website and we'll be glad to help.\n\nWarm regards,\nCEIBA",
};

export async function onRequestGet({ request, env }) {
  const unauth = await requireAuth(request, env);
  if (unauth) return unauth;
  const out = { ...DEFAULTS };
  try {
    await ensureBookingTables(env);
    const { results } = await env.DB.prepare(
      "SELECT key, value FROM app_settings WHERE key LIKE 'booking_%' OR key LIKE 'price_%' OR key LIKE 'chat_%' OR key LIKE 'email_%'"
    ).all();
    for (const r of results || []) out[r.key] = r.value;
  } catch (e) {
    return bad('Could not read settings: ' + (e && e.message ? e.message : 'unknown'), 500);
  }
  return json(out);
}

export async function onRequestPut({ request, env }) {
  const unauth = await requireAuth(request, env);
  if (unauth) return unauth;
  let b;
  try { b = await request.json(); } catch { return bad('Bad request', 400); }

  try {
    await ensureBookingTables(env);
    const clean = {};
    if ('booking_days' in b) {
      const days = String(b.booking_days).split(',').map((s) => parseInt(s, 10)).filter((n) => n >= 0 && n <= 6);
      clean.booking_days = [...new Set(days)].sort().join(',');
    }
    if ('booking_start' in b) clean.booking_start = normTime(b.booking_start, '09:00');
    if ('booking_end' in b) clean.booking_end = normTime(b.booking_end, '17:00');
    if ('booking_duration' in b) clean.booking_duration = String(clampInt(b.booking_duration, 5, 480, 30));
    if ('booking_buffer' in b) clean.booking_buffer = String(clampInt(b.booking_buffer, 0, 240, 0));
    if ('booking_lead_hours' in b) clean.booking_lead_hours = String(clampInt(b.booking_lead_hours, 0, 720, 24));
    if ('booking_horizon' in b) clean.booking_horizon = String(clampInt(b.booking_horizon, 1, 120, 21));
    if ('booking_timezone' in b) clean.booking_timezone = String(b.booking_timezone).slice(0, 60) || 'Europe/London';
    if ('price_individual' in b) clean.price_individual = String(clampInt(b.price_individual, 0, 99999, 95));
    if ('price_programme' in b) clean.price_programme = String(clampInt(b.price_programme, 0, 99999, 900));
    if ('price_group' in b) clean.price_group = String(clampInt(b.price_group, 0, 99999, 900));
    if ('price_group_was' in b) clean.price_group_was = String(clampInt(b.price_group_was, 0, 99999, 1200));
    if ('chat_launcher_text' in b) clean.chat_launcher_text = String(b.chat_launcher_text).slice(0, 40) || 'Chat with us';
    if ('chat_subtitle' in b) clean.chat_subtitle = String(b.chat_subtitle).slice(0, 60) || 'We usually reply within a few hours';
    if ('chat_intro' in b) clean.chat_intro = String(b.chat_intro).slice(0, 500) || DEFAULTS.chat_intro;
    if ('chat_auto_enabled' in b) clean.chat_auto_enabled = (b.chat_auto_enabled === '0' || b.chat_auto_enabled === false) ? '0' : '1';
    if ('chat_auto_minutes' in b) clean.chat_auto_minutes = String(clampInt(b.chat_auto_minutes, 1, 180, 10));
    if ('chat_auto_cta' in b) clean.chat_auto_cta = String(b.chat_auto_cta).slice(0, 60) || 'Send a message or book a call';
    if ('chat_auto_message' in b) clean.chat_auto_message = String(b.chat_auto_message).slice(0, 500) || DEFAULTS.chat_auto_message;
    if ('chat_quick_replies' in b) {
      let arr;
      try { arr = Array.isArray(b.chat_quick_replies) ? b.chat_quick_replies : JSON.parse(b.chat_quick_replies || '[]'); }
      catch { arr = []; }
      if (!Array.isArray(arr)) arr = [];
      const cleaned = arr.slice(0, 12).map((s) => ({
        label: String((s && s.label) || '').replace(/[\r\n]+/g, ' ').slice(0, 40),
        text: String((s && s.text) || '').slice(0, 1000),
      })).filter((s) => s.label || s.text);
      clean.chat_quick_replies = JSON.stringify(cleaned).slice(0, 8000);
    }
    if ('email_requested_subject' in b) clean.email_requested_subject = String(b.email_requested_subject).trim().slice(0, 150) || DEFAULTS.email_requested_subject;
    if ('email_requested_body' in b) clean.email_requested_body = String(b.email_requested_body).slice(0, 2000) || DEFAULTS.email_requested_body;
    if ('email_confirm_subject' in b) clean.email_confirm_subject = String(b.email_confirm_subject).trim().slice(0, 150) || DEFAULTS.email_confirm_subject;
    if ('email_confirm_body' in b) clean.email_confirm_body = String(b.email_confirm_body).slice(0, 2000) || DEFAULTS.email_confirm_body;
    if ('email_decline_subject' in b) clean.email_decline_subject = String(b.email_decline_subject).trim().slice(0, 150) || DEFAULTS.email_decline_subject;
    if ('email_decline_body' in b) clean.email_decline_body = String(b.email_decline_body).slice(0, 2000) || DEFAULTS.email_decline_body;

    for (const key of Object.keys(clean)) {
      if (!KEYS.includes(key)) continue;
      await env.DB.prepare(
        `INSERT INTO app_settings (key, value, updated_at) VALUES (?, ?, datetime('now'))
         ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')`
      ).bind(key, clean[key]).run();
    }

    const out = { ...DEFAULTS };
    const { results } = await env.DB.prepare(
      "SELECT key, value FROM app_settings WHERE key LIKE 'booking_%' OR key LIKE 'price_%' OR key LIKE 'chat_%' OR key LIKE 'email_%'"
    ).all();
    for (const r of results || []) out[r.key] = r.value;
    return json(out);
  } catch (e) {
    return bad('Could not save settings: ' + (e && e.message ? e.message : 'unknown'), 500);
  }
}

function clampInt(v, min, max, dflt) {
  const n = parseInt(v, 10);
  if (isNaN(n)) return dflt;
  return Math.min(max, Math.max(min, n));
}
function normTime(v, dflt) {
  const m = String(v).match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return dflt;
  const h = Math.min(23, Math.max(0, +m[1]));
  const mi = Math.min(59, Math.max(0, +m[2]));
  return `${String(h).padStart(2, '0')}:${String(mi).padStart(2, '0')}`;
}
