import { json, bad, requireAuth, notifySubmission, verifyTurnstile, rateLimited, tooManyRequests, clientIp } from '../_shared.js';

/* Public: capture a discovery-call enquiry. Accepts form-data or JSON. */
export async function onRequestPost({ request, env, waitUntil }) {
  if (await rateLimited(env, `submissions:${clientIp(request)}`, 5, 600)) return tooManyRequests();

  let data = {};
  const ct = request.headers.get('content-type') || '';
  try {
    if (ct.includes('application/json')) {
      data = await request.json();
    } else {
      const form = await request.formData();
      form.forEach(function (v, k) { data[k] = v; });
    }
  } catch {
    return bad('Could not read submission.', 400);
  }

  const ok = await verifyTurnstile(request, env, data.turnstileToken || data['cf-turnstile-response']);
  if (!ok) return bad('Verification failed. Please try again.', 403);

  const name = (data.name || '').toString().trim();
  const email = (data.email || '').toString().trim();
  const phone = (data.phone || '').toString().trim();
  const message = (data.message || '').toString().trim();

  if (!name || !email) return bad('Name and email are required.', 422);
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return bad('Please enter a valid email.', 422);
  if (name.length > 200 || email.length > 200 || phone.length > 60 || message.length > 4000) {
    return bad('One of the fields is too long.', 422);
  }

  const { meta } = await env.DB
    .prepare('INSERT INTO submissions (name, email, phone, message) VALUES (?, ?, ?, ?)')
    .bind(name, email, phone || null, message || null)
    .run();

  // Truly fire-and-forget via waitUntil, so the Resend call never delays
  // the visitor's success response.
  waitUntil(notifySubmission(env, { name, email, phone, message }));

  return json({ ok: true, id: meta.last_row_id });
}

/* Admin: list all enquiries, newest first. */
export async function onRequestGet({ request, env }) {
  const auth = await requireAuth(request, env);
  if (auth) return auth;
  const { results } = await env.DB
    .prepare('SELECT id, name, email, phone, message, admin_unread, created_at FROM submissions ORDER BY created_at DESC, id DESC')
    .all();
  const unread = results.reduce(function (n, r) { return n + (r.admin_unread ? 1 : 0); }, 0);
  return json({ submissions: results, total_unread: unread });
}
