import { json, bad, requireAuth } from '../../_shared.js';

/* Admin: mark an enquiry as read. */
export async function onRequestPatch({ request, env, params }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  const id = parseInt(params.id, 10);
  if (!id) return bad('Bad id', 400);
  await env.DB.prepare('UPDATE submissions SET admin_unread = 0 WHERE id = ?').bind(id).run();
  return json({ ok: true });
}

/* Admin: delete an enquiry. */
export async function onRequestDelete({ request, env, params }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  const id = parseInt(params.id, 10);
  if (!id) return bad('Bad id', 400);
  await env.DB.prepare('DELETE FROM submissions WHERE id = ?').bind(id).run();
  return json({ ok: true });
}
