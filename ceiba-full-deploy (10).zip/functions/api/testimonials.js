import { json, bad, requireAuth } from '../_shared.js';

// Public: published testimonials for the homepage slider.
export async function onRequestGet({ request, env }) {
  const admin = !(await requireAuth(request, env)); // authed sees all
  const sql = admin
    ? 'SELECT * FROM testimonials ORDER BY sort_order ASC, id DESC'
    : 'SELECT id, quote, author, role FROM testimonials WHERE published = 1 ORDER BY sort_order ASC, id DESC';
  const { results } = await env.DB.prepare(sql).all();
  return json(results || []);
}

// Admin: create
export async function onRequestPost({ request, env }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  let b; try { b = await request.json(); } catch { return bad('Bad request'); }
  if (!b.quote || !b.quote.trim()) return bad('Quote is required');
  const { meta } = await env.DB.prepare(
    'INSERT INTO testimonials (quote, author, role, published, sort_order) VALUES (?,?,?,?,?)'
  ).bind(b.quote.trim(), b.author || null, b.role || null, b.published ? 1 : 0, b.sort_order || 0).run();
  return json({ id: meta.last_row_id }, 201);
}
