import { json, bad, requireAuth } from '../../_shared.js';

export async function onRequestPut({ request, env, params }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  let b; try { b = await request.json(); } catch { return bad('Bad request'); }
  if (!b.quote || !b.quote.trim()) return bad('Quote is required');
  await env.DB.prepare(
    'UPDATE testimonials SET quote=?, author=?, role=?, published=?, sort_order=? WHERE id=?'
  ).bind(b.quote.trim(), b.author || null, b.role || null, b.published ? 1 : 0, b.sort_order || 0, params.id).run();
  return json({ ok: true });
}

export async function onRequestDelete({ request, env, params }) {
  const gate = await requireAuth(request, env); if (gate) return gate;
  await env.DB.prepare('DELETE FROM testimonials WHERE id=?').bind(params.id).run();
  return json({ ok: true });
}
