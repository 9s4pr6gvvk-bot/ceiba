import { json, bad, requireAuth } from '../_shared.js';

const ALLOWED = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
};
const MAX_BYTES = 8 * 1024 * 1024; // 8MB
const MAX_PHOTOS = 500;

/* file.type is set by the browser and can be spoofed, so don't trust it alone.
   Sniff the leading bytes and confirm they match a real image signature for
   the claimed type. Returns true if the bytes look like the declared format. */
async function bytesMatchType(file, declaredType) {
  const head = new Uint8Array(await file.slice(0, 16).arrayBuffer());
  const is = (sig, off = 0) => sig.every((b, i) => head[off + i] === b);
  switch (declaredType) {
    case 'image/jpeg': return is([0xff, 0xd8, 0xff]);
    case 'image/png':  return is([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
    case 'image/gif':  return is([0x47, 0x49, 0x46, 0x38]); // GIF8
    case 'image/webp': return is([0x52, 0x49, 0x46, 0x46]) && is([0x57, 0x45, 0x42, 0x50], 8); // RIFF....WEBP
    default: return false;
  }
}

export async function onRequestPost({ request, env }) {
  const gate = await requireAuth(request, env);
  if (gate) return gate;

  if (!env.IMAGES) {
    return bad('Image storage isn\u2019t set up yet \u2014 add the IMAGES R2 bucket binding in Cloudflare Pages settings.', 500);
  }

  let form;
  try { form = await request.formData(); } catch { return bad('Could not read upload.'); }
  const file = form.get('file');
  if (!file || typeof file === 'string') return bad('No file received.');

  const ext = ALLOWED[file.type];
  if (!ext) return bad('Only JPG, PNG, WebP, or GIF images are allowed.');
  if (file.size > MAX_BYTES) return bad('Image is too large \u2014 8MB max.');
  if (!(await bytesMatchType(file, file.type))) {
    return bad('That file doesn\u2019t look like a real image. Please upload a valid JPG, PNG, WebP, or GIF.');
  }

  const confirmDelete = form.get('confirm_delete_oldest') === '1';

  // Enforce the 500-photo cap. R2's list() covers up to 1000 in one call,
  // comfortably above the cap, so no pagination is needed as long as every
  // upload goes through this endpoint (nothing else writes to the bucket).
  const listed = await env.IMAGES.list({ limit: 1000 });
  const objects = listed.objects || [];
  if (objects.length >= MAX_PHOTOS) {
    const oldest = objects.reduce((a, b) => (a.uploaded < b.uploaded ? a : b));
    if (!confirmDelete) {
      return json({
        error: 'limit',
        message: `You\u2019ve reached the ${MAX_PHOTOS}-photo limit.`,
        oldest: { key: oldest.key, url: `/img/${oldest.key}`, uploaded: oldest.uploaded },
      }, 409);
    }
    await env.IMAGES.delete(oldest.key);
  }

  const key = `${crypto.randomUUID()}.${ext}`;
  await env.IMAGES.put(key, file.stream(), {
    httpMetadata: { contentType: file.type },
  });

  return json({ url: `/img/${key}` });
}
