import { shell, fmtDate } from './_layout.js';
import { escapeHtml } from './_shared.js';

export async function onRequestGet({ env }) {
  const { results } = await env.DB.prepare(
    'SELECT slug, title, excerpt, cover, published_at FROM posts WHERE published=1 ORDER BY published_at DESC'
  ).all();
  const posts = results || [];

  const cards = posts.map((p) => `
    <a class="post-card" href="/blog/${p.slug}">
      ${p.cover ? `<div class="cover" style="background-image:url('${escapeHtml(p.cover)}')"></div>` : ''}
      <div class="body">
        <span class="date">${fmtDate(p.published_at)}</span>
        <h3>${escapeHtml(p.title)}</h3>
        ${p.excerpt ? `<p>${escapeHtml(p.excerpt)}</p>` : ''}
        <span class="more">Read <span class="ln"></span></span>
      </div>
    </a>`).join('');

  const content = `
    <div class="wrap">
      <div class="page-head">
        <span class="kicker" style="justify-content:center">The CEIBA Journal</span>
        <h1>Reflections on growth, <em>change</em> &amp; the work beneath it.</h1>
        <p class="lede">Notes on transition, clarity and what it takes to grow from strong foundations.</p>
      </div>
      ${posts.length
        ? `<div class="post-grid">${cards}</div>`
        : `<p class="empty">The first reflections are being written. Please check back soon.</p>`}
    </div>`;

  return new Response(shell({
    title: 'Journal | CEIBA — Transformational Coaching',
    description: 'Reflections on growth, change and transition from CEIBA. Notes on clarity and building from strong foundations.',
    canonical: 'https://ceibamethod.co.uk/blog',
    bodyClass: 'blog-list',
    content,
  }), { headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'public, max-age=120' } });
}
