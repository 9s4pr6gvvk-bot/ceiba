import { shell, fmtDate } from '../_layout.js';
import { markdown, escapeHtml } from '../_shared.js';

export async function onRequestGet({ env, params }) {
  const post = await env.DB.prepare(
    'SELECT * FROM posts WHERE slug=? AND published=1'
  ).bind(params.slug).first();

  if (!post) {
    const content = `<div class="wrap"><div class="page-head"><h1>Not found</h1>
      <p class="lede">This reflection may have moved or is no longer published.</p>
      <p style="margin-top:26px"><a class="btn btn-fill" href="/blog">Back to the Journal</a></p></div></div>`;
    return new Response(shell({ title: 'Not found | CEIBA', content, canonical: 'https://ceibamethod.co.uk/blog' }),
      { status: 404, headers: { 'content-type': 'text/html; charset=utf-8' } });
  }

  const canonical = `https://ceibamethod.co.uk/blog/${post.slug}`;
  const ld = {
    '@context': 'https://schema.org', '@type': 'Article',
    headline: post.title, description: post.meta_description || post.excerpt || '',
    datePublished: post.published_at, dateModified: post.updated_at || post.published_at,
    author: { '@type': 'Organization', name: post.author || 'CEIBA' },
    image: post.cover || undefined, mainEntityOfPage: canonical,
  };

  const content = `
    <article class="post">
      <div class="crumbs" style="text-align:center"><a href="/blog">Journal</a> &rsaquo; ${escapeHtml(post.title)}</div>
      <span class="date">${fmtDate(post.published_at)}</span>
      <h1>${escapeHtml(post.title)}</h1>
      ${post.excerpt ? `<p class="excerpt">${escapeHtml(post.excerpt)}</p>` : ''}
      ${post.cover ? `<img class="cover" src="${escapeHtml(post.cover)}" alt="${escapeHtml(post.title)}" />` : ''}
      <div class="prose">${markdown(post.body)}</div>
    </article>
    <div class="post-foot">
      <div class="divider"></div>
      <p style="color:var(--muted); margin-bottom:26px; font-family:'Cormorant Garamond',serif; font-size:1.5rem; font-style:italic;">Ready to begin your own work?</p>
      <a class="btn btn-fill" href="/index.html#contact">Book a Discovery Call</a>
      &nbsp;&nbsp;
      <a class="btn btn-ghost" href="/blog">More from the Journal</a>
    </div>
    <script type="application/ld+json">${JSON.stringify(ld)}</script>`;

  return new Response(shell({
    title: `${post.title} | CEIBA Journal`,
    description: post.meta_description || post.excerpt || '',
    canonical, ogImage: post.cover, bodyClass: 'blog-post', content,
  }), { headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'public, max-age=120' } });
}
