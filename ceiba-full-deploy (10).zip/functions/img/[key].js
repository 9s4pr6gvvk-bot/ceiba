// Public: serves an uploaded image straight out of R2. No auth \u2014 these are
// blog/cover images meant to be publicly viewable, same as any other asset.
export async function onRequestGet({ env, params }) {
  if (!env.IMAGES) return new Response('Not found', { status: 404 });
  const obj = await env.IMAGES.get(params.key);
  if (!obj) return new Response('Not found', { status: 404 });
  return new Response(obj.body, {
    headers: {
      'content-type': obj.httpMetadata?.contentType || 'application/octet-stream',
      'x-content-type-options': 'nosniff',
      'cache-control': 'public, max-age=31536000, immutable',
      etag: obj.httpEtag,
    },
  });
}
