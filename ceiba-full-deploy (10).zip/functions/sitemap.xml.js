export async function onRequestGet({ env }) {
  const base = 'https://ceibamethod.co.uk';
  const staticUrls = ['/', '/about.html', '/individuals.html', '/organisations.html', '/groups.html'];
  const { results } = await env.DB.prepare(
    'SELECT slug, COALESCE(published_at, updated_at) AS d FROM posts WHERE published=1 ORDER BY published_at DESC'
  ).all();
  // Only advertise the journal index once it has at least one published post,
  // so an empty placeholder page isn't sent to search engines as thin content.
  if (results && results.length) staticUrls.push('/blog');
  const urls = [
    ...staticUrls.map((u) => `<url><loc>${base}${u}</loc></url>`),
    ...(results || []).map((p) => `<url><loc>${base}/blog/${p.slug}</loc>${p.d ? `<lastmod>${String(p.d).slice(0,10)}</lastmod>` : ''}</url>`),
  ].join('');
  const xml = `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls}</urlset>`;
  return new Response(xml, { headers: { 'content-type': 'application/xml; charset=utf-8', 'cache-control': 'public, max-age=3600' } });
}
