-- CEIBA live chat: automated "still with a client" wait-notice.
-- Run once against the live DB:
--   npx wrangler d1 execute ceiba-cms --remote --file=./migrate-chat-auto-notice.sql
--
-- Adds a flag column so the widget can tell an automated message apart
-- from one Frankie's client actually typed. Run this once only — SQLite
-- errors on ALTER TABLE ADD COLUMN if the column already exists.
--
-- Already run this one? You don't need to run it again — see
-- migrate-chat-settings.sql for the newer, separate migration that adds
-- the CMS-editable wording on top of this.

ALTER TABLE chat_messages ADD COLUMN is_auto INTEGER NOT NULL DEFAULT 0;
