-- CEIBA live chat: CMS-editable widget wording (launcher text, subtitle,
-- welcome message, and the automated wait-notice's content/timing).
-- Run once against the live DB:
--   npx wrangler d1 execute ceiba-cms --remote --file=./migrate-chat-settings.sql
--
-- Safe to run more than once — INSERT OR IGNORE won't touch a row that's
-- already there, so if Frankie has already edited one of these in the
-- admin console this won't overwrite it.
-- Requires migrate-chat-auto-notice.sql to have already been run once
-- (it needs app_settings, which that migration/schema.sql creates).

INSERT OR IGNORE INTO app_settings (key, value) VALUES
  ('chat_launcher_text', 'Chat with us'),
  ('chat_subtitle',      'We usually reply within a few hours'),
  ('chat_intro',         'Hello — thanks for stopping by. Leave a message and I''ll get back to you personally. If it''s outside working hours I''ll reply as soon as I can.'),
  ('chat_auto_enabled',  '1'),
  ('chat_auto_minutes',  '10'),
  ('chat_auto_cta',      'Send a message or book a call'),
  ('chat_auto_message',  'Thanks for your message — I may be with a client right now, but I''ll reply here or by email as soon as I''m free. If you''d rather not wait, feel free to send an enquiry or book a discovery call time directly.');
