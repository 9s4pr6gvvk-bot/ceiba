-- CEIBA CMS — Cloudflare D1 schema
-- Run once with:  npx wrangler d1 execute ceiba-cms --file=schema.sql --remote

CREATE TABLE IF NOT EXISTS testimonials (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  quote       TEXT    NOT NULL,
  author      TEXT,
  role        TEXT,
  published   INTEGER NOT NULL DEFAULT 1,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS posts (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  slug              TEXT    NOT NULL UNIQUE,
  title             TEXT    NOT NULL,
  excerpt           TEXT,
  body              TEXT    NOT NULL,           -- markdown source
  cover             TEXT,                       -- cover image URL
  meta_description  TEXT,
  author            TEXT    DEFAULT 'CEIBA',
  published         INTEGER NOT NULL DEFAULT 0,
  created_at        TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at        TEXT    NOT NULL DEFAULT (datetime('now')),
  published_at      TEXT
);

CREATE TABLE IF NOT EXISTS chat_threads (
  id             TEXT    PRIMARY KEY,           -- opaque visitor token
  name           TEXT,
  email          TEXT,
  created_at     TEXT    NOT NULL DEFAULT (datetime('now')),
  last_at        TEXT    NOT NULL DEFAULT (datetime('now')),
  admin_unread   INTEGER NOT NULL DEFAULT 0,    -- new visitor msgs the owner hasn't read
  visitor_unread INTEGER NOT NULL DEFAULT 0     -- new owner replies the visitor hasn't seen
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id   TEXT    NOT NULL,
  sender      TEXT    NOT NULL,                 -- 'visitor' | 'admin'
  body        TEXT    NOT NULL,
  is_auto     INTEGER NOT NULL DEFAULT 0,        -- 1 = automated "still with a client" notice
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_msg_thread   ON chat_messages(thread_id, id);
CREATE INDEX IF NOT EXISTS idx_threads_last ON chat_threads(last_at DESC);
CREATE INDEX IF NOT EXISTS idx_posts_pub    ON posts(published, published_at DESC);

CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  message TEXT,
  admin_unread INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_submissions_created ON submissions(created_at DESC);

-- Booking system: slot-based bookings + admin-configurable availability.
CREATE TABLE IF NOT EXISTS bookings (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  token           TEXT    NOT NULL UNIQUE,
  name            TEXT    NOT NULL,
  email           TEXT    NOT NULL,
  phone           TEXT    DEFAULT '',
  service         TEXT    DEFAULT '',
  slot_start      TEXT    NOT NULL,
  duration_min    INTEGER DEFAULT 30,
  note            TEXT    DEFAULT '',
  status          TEXT    DEFAULT 'pending',
  admin_note      TEXT    DEFAULT '',
  seen_by_admin   INTEGER DEFAULT 0,
  created_at      TEXT    DEFAULT (datetime('now')),
  updated_at      TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_token  ON bookings(token);
CREATE INDEX IF NOT EXISTS idx_bookings_slot   ON bookings(slot_start);

CREATE TABLE IF NOT EXISTS app_settings (
  key        TEXT PRIMARY KEY,
  value      TEXT DEFAULT '',
  updated_at TEXT DEFAULT (datetime('now'))
);
INSERT OR IGNORE INTO app_settings (key, value) VALUES
  ('booking_days',       '1,2,3,4,5'),
  ('booking_start',      '09:00'),
  ('booking_end',        '17:00'),
  ('booking_duration',   '30'),
  ('booking_buffer',     '0'),
  ('booking_lead_hours', '24'),
  ('booking_horizon',    '21'),
  ('booking_timezone',   'Europe/London'),
  ('chat_launcher_text', 'Chat with us'),
  ('chat_subtitle',      'We usually reply within a few hours'),
  ('chat_intro',         'Hello — thanks for stopping by. Leave a message and I''ll get back to you personally. If it''s outside working hours I''ll reply as soon as I can.'),
  ('chat_auto_enabled',  '1'),
  ('chat_auto_minutes',  '10'),
  ('chat_auto_cta',      'Send a message or book a call'),
  ('chat_auto_message',  'Thanks for your message — I may be with a client right now, but I''ll reply here or by email as soon as I''m free. If you''d rather not wait, feel free to send an enquiry or book a discovery call time directly.');
